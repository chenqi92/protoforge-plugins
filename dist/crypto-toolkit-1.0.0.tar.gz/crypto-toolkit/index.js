/**
 * crypto-toolkit — ProtoForge 加密解密工具箱插件
 *
 * 导出函数：
 *   encrypt(algorithmId, input, params) → { success, output, error }
 *   decrypt(algorithmId, input, params) → { success, output, error }
 *
 * 支持算法：
 *   - base64:     Base64 编码/解码
 *   - url-encode: URL 编码/解码
 *   - hex:        Hex 编码/解码
 *   - md5:        MD5 哈希（仅加密）
 *   - sha1:       SHA-1 哈希（仅加密）
 *   - sha256:     SHA-256 哈希（仅加密）
 *   - aes-cbc:    AES-CBC 加密/解密
 *   - aes-ecb:    AES-ECB 加密/解密
 *
 * 在脚本中调用示例（安装插件后可用）：
 *   var result = encrypt("base64", "hello world", {});
 *   console.log(result.output); // "aGVsbG8gd29ybGQ="
 *
 *   var decoded = decrypt("base64", "aGVsbG8gd29ybGQ=", {});
 *   console.log(decoded.output); // "hello world"
 *
 *   var hash = encrypt("md5", "hello", {});
 *   console.log(hash.output); // "5d41402abc4b2a76b9719d911017c592"
 *
 *   var encrypted = encrypt("aes-cbc", "plaintext", {
 *     key: "1234567890123456",
 *     iv: "1234567890123456",
 *     padding: "pkcs7",
 *     outputEncoding: "base64"
 *   });
 */

// ── 工具函数 ──

function ok(output) {
  return { success: true, output: output, error: null };
}

function fail(msg) {
  return { success: false, output: "", error: msg };
}

// ── Base64 ──
// 在 Boa engine 中没有 btoa/atob，手写实现

var BASE64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

function base64Encode(str) {
  var bytes = [];
  for (var i = 0; i < str.length; i++) {
    var code = str.charCodeAt(i);
    if (code < 0x80) {
      bytes.push(code);
    } else if (code < 0x800) {
      bytes.push(0xc0 | (code >> 6), 0x80 | (code & 0x3f));
    } else {
      bytes.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 0x3f), 0x80 | (code & 0x3f));
    }
  }
  var result = "";
  for (var i = 0; i < bytes.length; i += 3) {
    var b0 = bytes[i];
    var b1 = i + 1 < bytes.length ? bytes[i + 1] : 0;
    var b2 = i + 2 < bytes.length ? bytes[i + 2] : 0;
    result += BASE64_CHARS[(b0 >> 2) & 0x3f];
    result += BASE64_CHARS[((b0 << 4) | (b1 >> 4)) & 0x3f];
    result += (i + 1 < bytes.length) ? BASE64_CHARS[((b1 << 2) | (b2 >> 6)) & 0x3f] : "=";
    result += (i + 2 < bytes.length) ? BASE64_CHARS[b2 & 0x3f] : "=";
  }
  return result;
}

function base64Decode(str) {
  str = str.replace(/=+$/, "");
  var lookup = {};
  for (var i = 0; i < BASE64_CHARS.length; i++) { lookup[BASE64_CHARS[i]] = i; }
  var bytes = [];
  for (var i = 0; i < str.length; i += 4) {
    var a = lookup[str[i]] || 0;
    var b = lookup[str[i + 1]] || 0;
    var c = lookup[str[i + 2]] || 0;
    var d = lookup[str[i + 3]] || 0;
    bytes.push((a << 2) | (b >> 4));
    if (str[i + 2] !== undefined) bytes.push(((b << 4) | (c >> 2)) & 0xff);
    if (str[i + 3] !== undefined) bytes.push(((c << 6) | d) & 0xff);
  }
  // UTF-8 decode
  var result = "";
  for (var i = 0; i < bytes.length; ) {
    var b = bytes[i];
    if (b < 0x80) {
      result += String.fromCharCode(b);
      i++;
    } else if ((b & 0xe0) === 0xc0) {
      result += String.fromCharCode(((b & 0x1f) << 6) | (bytes[i + 1] & 0x3f));
      i += 2;
    } else {
      result += String.fromCharCode(((b & 0x0f) << 12) | ((bytes[i + 1] & 0x3f) << 6) | (bytes[i + 2] & 0x3f));
      i += 3;
    }
  }
  return result;
}

// ── Hex ──

function hexEncode(str) {
  var result = "";
  for (var i = 0; i < str.length; i++) {
    var hex = str.charCodeAt(i).toString(16);
    result += hex.length < 2 ? "0" + hex : hex;
  }
  return result;
}

function hexDecode(hex) {
  hex = hex.replace(/\s+/g, "");
  var result = "";
  for (var i = 0; i < hex.length; i += 2) {
    result += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
  }
  return result;
}

// ── MD5 (RFC 1321) ──
// Pure JavaScript MD5 implementation

function md5(str) {
  function safeAdd(x, y) {
    var lsw = (x & 0xFFFF) + (y & 0xFFFF);
    var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
    return (msw << 16) | (lsw & 0xFFFF);
  }
  function bitRotateLeft(num, cnt) {
    return (num << cnt) | (num >>> (32 - cnt));
  }
  function md5cmn(q, a, b, x, s, t) {
    return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
  }
  function md5ff(a, b, c, d, x, s, t) { return md5cmn((b & c) | ((~b) & d), a, b, x, s, t); }
  function md5gg(a, b, c, d, x, s, t) { return md5cmn((b & d) | (c & (~d)), a, b, x, s, t); }
  function md5hh(a, b, c, d, x, s, t) { return md5cmn(b ^ c ^ d, a, b, x, s, t); }
  function md5ii(a, b, c, d, x, s, t) { return md5cmn(c ^ (b | (~d)), a, b, x, s, t); }

  function binlMD5(x, len) {
    x[len >> 5] |= 0x80 << (len % 32);
    x[(((len + 64) >>> 9) << 4) + 14] = len;
    var a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
    for (var i = 0; i < x.length; i += 16) {
      var olda = a, oldb = b, oldc = c, oldd = d;
      a = md5ff(a, b, c, d, x[i], 7, -680876936);
      d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
      c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
      b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
      a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
      d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
      c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
      b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
      a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
      d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
      c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
      b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
      a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
      d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
      c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
      b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
      a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
      d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
      c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
      b = md5gg(b, c, d, a, x[i], 20, -373897302);
      a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
      d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
      c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
      b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
      a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
      d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
      c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
      b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
      a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
      d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
      c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
      b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
      a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
      d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
      c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
      b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
      a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
      d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
      c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
      b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
      a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
      d = md5hh(d, a, b, c, x[i + 0], 11, -358537222);
      c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
      b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
      a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
      d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
      c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
      b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
      a = md5ii(a, b, c, d, x[i], 6, -198630844);
      d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
      c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
      b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
      a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
      d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
      c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
      b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
      a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
      d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
      c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
      b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
      a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
      d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
      c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
      b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
      a = safeAdd(a, olda);
      b = safeAdd(b, oldb);
      c = safeAdd(c, oldc);
      d = safeAdd(d, oldd);
    }
    return [a, b, c, d];
  }

  function str2binl(str) {
    var output = [];
    for (var i = 0; i < str.length * 8; i += 8) {
      output[i >> 5] |= (str.charCodeAt(i / 8) & 0xFF) << (i % 32);
    }
    return output;
  }

  function binl2hex(binarray) {
    var hexTab = "0123456789abcdef";
    var str = "";
    for (var i = 0; i < binarray.length * 4; i++) {
      str += hexTab.charAt((binarray[i >> 2] >> ((i % 4) * 8 + 4)) & 0xF) +
             hexTab.charAt((binarray[i >> 2] >> ((i % 4) * 8)) & 0xF);
    }
    return str;
  }

  return binl2hex(binlMD5(str2binl(str), str.length * 8));
}

// ── SHA-256 (FIPS 180-4) ──

function sha256(str) {
  var K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ];
  function rotr(n, x) { return (x >>> n) | (x << (32 - n)); }
  function ch(x, y, z) { return (x & y) ^ ((~x) & z); }
  function maj(x, y, z) { return (x & y) ^ (x & z) ^ (y & z); }
  function sigma0(x) { return rotr(2, x) ^ rotr(13, x) ^ rotr(22, x); }
  function sigma1(x) { return rotr(6, x) ^ rotr(11, x) ^ rotr(25, x); }
  function gamma0(x) { return rotr(7, x) ^ rotr(18, x) ^ (x >>> 3); }
  function gamma1(x) { return rotr(17, x) ^ rotr(19, x) ^ (x >>> 10); }

  // Encode string to bytes
  var bytes = [];
  for (var i = 0; i < str.length; i++) {
    var c = str.charCodeAt(i);
    if (c < 128) bytes.push(c);
    else if (c < 2048) { bytes.push(192 | (c >> 6)); bytes.push(128 | (c & 63)); }
    else { bytes.push(224 | (c >> 12)); bytes.push(128 | ((c >> 6) & 63)); bytes.push(128 | (c & 63)); }
  }

  var bitLen = bytes.length * 8;
  bytes.push(0x80);
  while (bytes.length % 64 !== 56) bytes.push(0);
  // Append big-endian 64-bit length
  for (var i = 56; i >= 0; i -= 8) {
    bytes.push((bitLen >>> i) & 0xff);
  }

  var H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];

  for (var offset = 0; offset < bytes.length; offset += 64) {
    var W = [];
    for (var t = 0; t < 16; t++) {
      W[t] = (bytes[offset + t * 4] << 24) | (bytes[offset + t * 4 + 1] << 16) |
             (bytes[offset + t * 4 + 2] << 8) | bytes[offset + t * 4 + 3];
    }
    for (var t = 16; t < 64; t++) {
      W[t] = (gamma1(W[t - 2]) + W[t - 7] + gamma0(W[t - 15]) + W[t - 16]) | 0;
    }
    var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
    for (var t = 0; t < 64; t++) {
      var T1 = (h + sigma1(e) + ch(e, f, g) + K[t] + W[t]) | 0;
      var T2 = (sigma0(a) + maj(a, b, c)) | 0;
      h = g; g = f; f = e; e = (d + T1) | 0;
      d = c; c = b; b = a; a = (T1 + T2) | 0;
    }
    H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
    H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
  }

  var hex = "";
  for (var i = 0; i < 8; i++) {
    for (var j = 28; j >= 0; j -= 4) {
      hex += "0123456789abcdef".charAt((H[i] >>> j) & 0xf);
    }
  }
  return hex;
}

// ── SHA-1 (FIPS 180-4) ──

function sha1(str) {
  var bytes = [];
  for (var i = 0; i < str.length; i++) {
    var c = str.charCodeAt(i);
    if (c < 128) bytes.push(c);
    else if (c < 2048) { bytes.push(192 | (c >> 6)); bytes.push(128 | (c & 63)); }
    else { bytes.push(224 | (c >> 12)); bytes.push(128 | ((c >> 6) & 63)); bytes.push(128 | (c & 63)); }
  }
  var bitLen = bytes.length * 8;
  bytes.push(0x80);
  while (bytes.length % 64 !== 56) bytes.push(0);
  for (var i = 56; i >= 0; i -= 8) bytes.push((bitLen >>> i) & 0xff);

  var H = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0];

  for (var offset = 0; offset < bytes.length; offset += 64) {
    var W = [];
    for (var t = 0; t < 16; t++) {
      W[t] = (bytes[offset + t * 4] << 24) | (bytes[offset + t * 4 + 1] << 16) |
             (bytes[offset + t * 4 + 2] << 8) | bytes[offset + t * 4 + 3];
    }
    for (var t = 16; t < 80; t++) {
      var w = W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16];
      W[t] = (w << 1) | (w >>> 31);
    }
    var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4];
    for (var t = 0; t < 80; t++) {
      var f, k;
      if (t < 20) { f = (b & c) | ((~b) & d); k = 0x5A827999; }
      else if (t < 40) { f = b ^ c ^ d; k = 0x6ED9EBA1; }
      else if (t < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC; }
      else { f = b ^ c ^ d; k = 0xCA62C1D6; }
      var temp = (((a << 5) | (a >>> 27)) + f + e + k + W[t]) | 0;
      e = d; d = c; c = (b << 30) | (b >>> 2); b = a; a = temp;
    }
    H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0;
    H[3] = (H[3] + d) | 0; H[4] = (H[4] + e) | 0;
  }

  var hex = "";
  for (var i = 0; i < 5; i++) {
    for (var j = 28; j >= 0; j -= 4) {
      hex += "0123456789abcdef".charAt((H[i] >>> j) & 0xf);
    }
  }
  return hex;
}

// ── AES ──
// Pure JavaScript AES implementation (128/192/256-bit keys)

var AES_SBOX = [
  0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
  0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
  0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
  0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
  0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
  0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
  0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
  0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
  0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
  0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
  0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
  0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
  0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
  0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
  0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
  0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
];

var AES_INV_SBOX = [];
for (var i = 0; i < 256; i++) AES_INV_SBOX[AES_SBOX[i]] = i;

var AES_RCON = [0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36];

function aesKeyExpansion(key) {
  var Nk = key.length / 4;
  var Nr = Nk + 6;
  var W = [];
  for (var i = 0; i < Nk; i++) {
    W[i] = (key[4*i] << 24) | (key[4*i+1] << 16) | (key[4*i+2] << 8) | key[4*i+3];
  }
  for (var i = Nk; i < 4 * (Nr + 1); i++) {
    var temp = W[i - 1];
    if (i % Nk === 0) {
      temp = ((AES_SBOX[(temp >> 16) & 0xff] << 24) | (AES_SBOX[(temp >> 8) & 0xff] << 16) |
              (AES_SBOX[temp & 0xff] << 8) | AES_SBOX[(temp >> 24) & 0xff]) ^ (AES_RCON[i/Nk - 1] << 24);
    } else if (Nk > 6 && i % Nk === 4) {
      temp = (AES_SBOX[(temp >> 24) & 0xff] << 24) | (AES_SBOX[(temp >> 16) & 0xff] << 16) |
             (AES_SBOX[(temp >> 8) & 0xff] << 8) | AES_SBOX[temp & 0xff];
    }
    W[i] = W[i - Nk] ^ temp;
  }
  return { W: W, Nr: Nr };
}

function aesEncryptBlock(block, expanded) {
  var W = expanded.W, Nr = expanded.Nr;
  var s = [];
  for (var i = 0; i < 16; i++) s[i] = block[i];
  // AddRoundKey
  for (var i = 0; i < 4; i++) {
    var w = W[i];
    s[4*i] ^= (w >> 24) & 0xff; s[4*i+1] ^= (w >> 16) & 0xff;
    s[4*i+2] ^= (w >> 8) & 0xff; s[4*i+3] ^= w & 0xff;
  }
  for (var round = 1; round <= Nr; round++) {
    // SubBytes
    for (var i = 0; i < 16; i++) s[i] = AES_SBOX[s[i]];
    // ShiftRows
    var t = s[1]; s[1] = s[5]; s[5] = s[9]; s[9] = s[13]; s[13] = t;
    t = s[2]; s[2] = s[10]; s[10] = t; t = s[6]; s[6] = s[14]; s[14] = t;
    t = s[15]; s[15] = s[11]; s[11] = s[7]; s[7] = s[3]; s[3] = t;
    // MixColumns (skip last round)
    if (round < Nr) {
      for (var col = 0; col < 4; col++) {
        var i = col * 4;
        var a0 = s[i], a1 = s[i+1], a2 = s[i+2], a3 = s[i+3];
        s[i]   = gmul(2,a0) ^ gmul(3,a1) ^ a2 ^ a3;
        s[i+1] = a0 ^ gmul(2,a1) ^ gmul(3,a2) ^ a3;
        s[i+2] = a0 ^ a1 ^ gmul(2,a2) ^ gmul(3,a3);
        s[i+3] = gmul(3,a0) ^ a1 ^ a2 ^ gmul(2,a3);
      }
    }
    // AddRoundKey
    for (var i = 0; i < 4; i++) {
      var w = W[round * 4 + i];
      s[4*i] ^= (w >> 24) & 0xff; s[4*i+1] ^= (w >> 16) & 0xff;
      s[4*i+2] ^= (w >> 8) & 0xff; s[4*i+3] ^= w & 0xff;
    }
  }
  return s;
}

function aesDecryptBlock(block, expanded) {
  var W = expanded.W, Nr = expanded.Nr;
  var s = [];
  for (var i = 0; i < 16; i++) s[i] = block[i];
  // AddRoundKey (last)
  for (var i = 0; i < 4; i++) {
    var w = W[Nr * 4 + i];
    s[4*i] ^= (w >> 24) & 0xff; s[4*i+1] ^= (w >> 16) & 0xff;
    s[4*i+2] ^= (w >> 8) & 0xff; s[4*i+3] ^= w & 0xff;
  }
  for (var round = Nr - 1; round >= 0; round--) {
    // InvShiftRows
    var t = s[13]; s[13] = s[9]; s[9] = s[5]; s[5] = s[1]; s[1] = t;
    t = s[10]; s[10] = s[2]; s[2] = t; t = s[14]; s[14] = s[6]; s[6] = t;
    t = s[3]; s[3] = s[7]; s[7] = s[11]; s[11] = s[15]; s[15] = t;
    // InvSubBytes
    for (var i = 0; i < 16; i++) s[i] = AES_INV_SBOX[s[i]];
    // AddRoundKey
    for (var i = 0; i < 4; i++) {
      var w = W[round * 4 + i];
      s[4*i] ^= (w >> 24) & 0xff; s[4*i+1] ^= (w >> 16) & 0xff;
      s[4*i+2] ^= (w >> 8) & 0xff; s[4*i+3] ^= w & 0xff;
    }
    // InvMixColumns (skip round 0)
    if (round > 0) {
      for (var col = 0; col < 4; col++) {
        var i = col * 4;
        var a0 = s[i], a1 = s[i+1], a2 = s[i+2], a3 = s[i+3];
        s[i]   = gmul(14,a0) ^ gmul(11,a1) ^ gmul(13,a2) ^ gmul(9,a3);
        s[i+1] = gmul(9,a0) ^ gmul(14,a1) ^ gmul(11,a2) ^ gmul(13,a3);
        s[i+2] = gmul(13,a0) ^ gmul(9,a1) ^ gmul(14,a2) ^ gmul(11,a3);
        s[i+3] = gmul(11,a0) ^ gmul(13,a1) ^ gmul(9,a2) ^ gmul(14,a3);
      }
    }
  }
  return s;
}

function gmul(a, b) {
  var p = 0;
  for (var i = 0; i < 8; i++) {
    if (b & 1) p ^= a;
    var hi = a & 0x80;
    a = (a << 1) & 0xff;
    if (hi) a ^= 0x1b;
    b >>= 1;
  }
  return p;
}

function pkcs7Pad(data, blockSize) {
  var padLen = blockSize - (data.length % blockSize);
  var result = data.slice();
  for (var i = 0; i < padLen; i++) result.push(padLen);
  return result;
}

function pkcs7Unpad(data) {
  if (data.length === 0) return data;
  var padLen = data[data.length - 1];
  if (padLen > 16 || padLen === 0) return data;
  return data.slice(0, data.length - padLen);
}

function zeroPad(data, blockSize) {
  var result = data.slice();
  while (result.length % blockSize !== 0) result.push(0);
  return result;
}

function strToBytes(str) {
  var bytes = [];
  for (var i = 0; i < str.length; i++) bytes.push(str.charCodeAt(i) & 0xff);
  return bytes;
}

function bytesToStr(bytes) {
  var str = "";
  for (var i = 0; i < bytes.length; i++) str += String.fromCharCode(bytes[i]);
  return str;
}

function bytesToHex(bytes) {
  var hex = "";
  for (var i = 0; i < bytes.length; i++) {
    var h = bytes[i].toString(16);
    hex += h.length < 2 ? "0" + h : h;
  }
  return hex;
}

function hexToBytes(hex) {
  var bytes = [];
  for (var i = 0; i < hex.length; i += 2) {
    bytes.push(parseInt(hex.substr(i, 2), 16));
  }
  return bytes;
}

function aesCbcEncrypt(plainBytes, keyBytes, ivBytes, padding) {
  var expanded = aesKeyExpansion(keyBytes);
  var padded = padding === "pkcs7" ? pkcs7Pad(plainBytes, 16) : 
               padding === "zero" ? zeroPad(plainBytes, 16) : plainBytes;
  var result = [];
  var prev = ivBytes.slice();
  for (var i = 0; i < padded.length; i += 16) {
    var block = [];
    for (var j = 0; j < 16; j++) block[j] = (padded[i + j] || 0) ^ prev[j];
    var encrypted = aesEncryptBlock(block, expanded);
    for (var j = 0; j < 16; j++) result.push(encrypted[j]);
    prev = encrypted;
  }
  return result;
}

function aesCbcDecrypt(cipherBytes, keyBytes, ivBytes, padding) {
  var expanded = aesKeyExpansion(keyBytes);
  var result = [];
  var prev = ivBytes.slice();
  for (var i = 0; i < cipherBytes.length; i += 16) {
    var block = cipherBytes.slice(i, i + 16);
    var decrypted = aesDecryptBlock(block, expanded);
    for (var j = 0; j < 16; j++) result.push(decrypted[j] ^ prev[j]);
    prev = block;
  }
  if (padding === "pkcs7") result = pkcs7Unpad(result);
  return result;
}

function aesEcbEncrypt(plainBytes, keyBytes, padding) {
  var expanded = aesKeyExpansion(keyBytes);
  var padded = padding === "pkcs7" ? pkcs7Pad(plainBytes, 16) :
               padding === "zero" ? zeroPad(plainBytes, 16) : plainBytes;
  var result = [];
  for (var i = 0; i < padded.length; i += 16) {
    var block = padded.slice(i, i + 16);
    var encrypted = aesEncryptBlock(block, expanded);
    for (var j = 0; j < 16; j++) result.push(encrypted[j]);
  }
  return result;
}

function aesEcbDecrypt(cipherBytes, keyBytes, padding) {
  var expanded = aesKeyExpansion(keyBytes);
  var result = [];
  for (var i = 0; i < cipherBytes.length; i += 16) {
    var block = cipherBytes.slice(i, i + 16);
    var decrypted = aesDecryptBlock(block, expanded);
    for (var j = 0; j < 16; j++) result.push(decrypted[j]);
  }
  if (padding === "pkcs7") result = pkcs7Unpad(result);
  return result;
}

// ── 入口函数 ──

function encrypt(algorithmId, input, params) {
  try {
    switch (algorithmId) {
      case "base64":
        return ok(base64Encode(input));
      case "url-encode":
        return ok(encodeURIComponent(input));
      case "hex":
        return ok(hexEncode(input));
      case "md5":
        return ok(md5(input));
      case "sha256":
        return ok(sha256(input));
      case "sha1":
        return ok(sha1(input));
      case "aes-cbc": {
        var key = strToBytes(params.key || "");
        var iv = strToBytes(params.iv || "");
        if (key.length !== 16 && key.length !== 24 && key.length !== 32) return fail("密钥长度必须为 16/24/32 字节");
        if (iv.length !== 16) return fail("IV 长度必须为 16 字节");
        var padding = params.padding || "pkcs7";
        var enc = params.outputEncoding || "base64";
        var result = aesCbcEncrypt(strToBytes(input), key, iv, padding);
        return ok(enc === "hex" ? bytesToHex(result) : base64Encode(bytesToStr(result)));
      }
      case "aes-ecb": {
        var key = strToBytes(params.key || "");
        if (key.length !== 16 && key.length !== 24 && key.length !== 32) return fail("密钥长度必须为 16/24/32 字节");
        var padding = params.padding || "pkcs7";
        var enc = params.outputEncoding || "base64";
        var result = aesEcbEncrypt(strToBytes(input), key, padding);
        return ok(enc === "hex" ? bytesToHex(result) : base64Encode(bytesToStr(result)));
      }
      default:
        return fail("不支持的算法: " + algorithmId);
    }
  } catch (e) {
    return fail("加密失败: " + e);
  }
}

function decrypt(algorithmId, input, params) {
  try {
    switch (algorithmId) {
      case "base64":
        return ok(base64Decode(input));
      case "url-encode":
        return ok(decodeURIComponent(input));
      case "hex":
        return ok(hexDecode(input));
      case "aes-cbc": {
        var key = strToBytes(params.key || "");
        var iv = strToBytes(params.iv || "");
        if (key.length !== 16 && key.length !== 24 && key.length !== 32) return fail("密钥长度必须为 16/24/32 字节");
        if (iv.length !== 16) return fail("IV 长度必须为 16 字节");
        var padding = params.padding || "pkcs7";
        var enc = params.outputEncoding || "base64";
        var cipherBytes = enc === "hex" ? hexToBytes(input) : strToBytes(base64Decode(input));
        var result = aesCbcDecrypt(cipherBytes, key, iv, padding);
        return ok(bytesToStr(result));
      }
      case "aes-ecb": {
        var key = strToBytes(params.key || "");
        if (key.length !== 16 && key.length !== 24 && key.length !== 32) return fail("密钥长度必须为 16/24/32 字节");
        var padding = params.padding || "pkcs7";
        var enc = params.outputEncoding || "base64";
        var cipherBytes = enc === "hex" ? hexToBytes(input) : strToBytes(base64Decode(input));
        var result = aesEcbDecrypt(cipherBytes, key, padding);
        return ok(bytesToStr(result));
      }
      default:
        return fail("不支持的算法: " + algorithmId);
    }
  } catch (e) {
    return fail("解密失败: " + e);
  }
}
