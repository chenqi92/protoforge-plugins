/**
 * timestamp-signer — 请求时间戳签名插件
 * 
 * 在请求发送前 (pre-request) 自动注入:
 *   X-Timestamp: 当前 Unix 毫秒时间戳
 *   X-Signature: 基于 method + url + timestamp 的简单哈希签名
 *   X-Nonce:     6 位随机字符串 (防重放)
 *
 * hook(request) → { headers: {...}, queryParams: {...} }
 */

function hook(request) {
  var timestamp = Date.now().toString();
  var nonce = randomString(6);

  // 简单签名：将 method + url + timestamp + nonce 拼接后计算 hash
  var signPayload = (request.method || "GET") + "|" + (request.url || "") + "|" + timestamp + "|" + nonce;
  var signature = simpleHash(signPayload);

  return {
    headers: {
      "X-Timestamp": timestamp,
      "X-Signature": signature,
      "X-Nonce": nonce
    },
    queryParams: {}
  };
}

// 简单的字符串 hash 函数 (djb2 变体)
function simpleHash(str) {
  var hash = 5381;
  for (var i = 0; i < str.length; i++) {
    hash = ((hash * 33) ^ str.charCodeAt(i)) >>> 0;
  }
  return hash.toString(16);
}

// 生成随机字符串
function randomString(len) {
  var chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  var result = "";
  for (var i = 0; i < len; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
