/**
 * SFJK-200 可燃气体控制器 MODBUS 通讯协议完整解析器 + 报文生成器
 *
 * 完全支持 SFJK-200 可燃气体检测报警控制器的 Modbus-RTU 通讯
 * 适用于可燃气体、有毒气体、氧气等探测器状态与浓度数据
 *
 * Modbus-RTU 响应帧格式:
 *   [地址1B] [功能码1B] [字节数1B] [数据NB] [CRC16-2B(低位在前)]
 *
 * Modbus-RTU 请求帧格式:
 *   [地址1B] [功能码1B] [起始寄存器2B(高位在前)] [读取数量2B(高位在前)] [CRC16-2B(低位在前)]
 */

// ═══════════════════════════════════════════
//  CRC-16/Modbus
// ═══════════════════════════════════════════

function crc16Modbus(bytes) {
  var crc = 0xFFFF;
  for (var i = 0; i < bytes.length; i++) {
    crc = crc ^ (bytes[i] & 0xFF);
    for (var j = 0; j < 8; j++) {
      if ((crc & 1) !== 0) {
        crc = (crc >> 1) ^ 0xA001;
      } else {
        crc = crc >> 1;
      }
    }
    crc = crc & 0xFFFF;
  }
  return crc;
}

// ═══════════════════════════════════════════
//  工具函数
// ═══════════════════════════════════════════

function hexToBytes(hex) {
  hex = hex.replace(/\s+/g, "");
  var bytes = [];
  for (var i = 0; i < hex.length; i += 2) {
    bytes.push(parseInt(hex.substring(i, i + 2), 16));
  }
  return bytes;
}

function bytesToHex(bytes) {
  var r = "";
  for (var i = 0; i < bytes.length; i++) {
    var h = bytes[i].toString(16).toUpperCase();
    if (h.length < 2) h = "0" + h;
    r += h;
  }
  return r;
}

function padHex(val, len) {
  var s = val.toString(16).toUpperCase();
  while (s.length < len) s = "0" + s;
  return s;
}

function readUint16BE(bytes, offset) {
  return ((bytes[offset] & 0xFF) << 8) | (bytes[offset + 1] & 0xFF);
}

function readUint16LE(bytes, offset) {
  return (bytes[offset] & 0xFF) | ((bytes[offset + 1] & 0xFF) << 8);
}

// ═══════════════════════════════════════════
//  气体单位类型
// ═══════════════════════════════════════════

var UNIT_TYPES = {
  0: { unit: "ppm", name: "有毒气体(大量程)", rate: 1 },
  1: { unit: "%LEL", name: "可燃气体", rate: 10 },
  2: { unit: "%V/V", name: "氧气/氮气等", rate: 10 },
  3: { unit: "ppm", name: "有毒气体(小量程)", rate: 10 }
};

// ═══════════════════════════════════════════
//  气体类型 (254种) — 精简为关键子集 + 查表
// ═══════════════════════════════════════════

var GAS_TYPES = {
  1: "输入模块", 2: "输入输出模块",
  10: "天然气", 11: "液化石油气", 12: "氢气", 13: "甲烷", 14: "乙烷", 15: "丙烷",
  16: "环丙烷", 17: "丁烷", 18: "异丁烷", 19: "正戊烷", 20: "己烷",
  21: "环己烷", 22: "庚烷", 23: "辛烷", 24: "癸烷", 25: "萘",
  26: "环戊烷", 27: "甲基环戊烷", 28: "甲基环己烷", 29: "二甲基环己烷", 30: "乙基环己烷",
  31: "二甲氧基甲烷", 32: "三甲氧基甲烷", 33: "硝基甲烷", 34: "硝基己烷",
  35: "环氧丙烷", 36: "氯乙烷", 37: "氯丙烷", 38: "氯丁烷",
  39: "乙烯", 40: "丙烯", 41: "丙二烯", 42: "丁烯", 43: "异丁烯",
  44: "丁二烯", 45: "反丁烯", 46: "环戊烯", 47: "苯乙烯", 48: "二氯乙烯",
  49: "醋酸乙烯", 50: "乙炔", 51: "丙炔",
  52: "汽油", 53: "煤油", 54: "柴油", 55: "航空煤油", 56: "石油醚",
  57: "石脑油", 58: "香蕉水", 59: "松节油", 60: "四氢呋喃", 61: "溶剂油",
  62: "吡啶", 63: "甲苯", 64: "二甲苯", 65: "乙苯", 66: "氯苯",
  67: "甲基异丙基苯",
  68: "甲醚", 69: "乙醚", 70: "甲乙醚", 71: "乙烯基甲醚", 72: "乙二醇二甲醚",
  73: "二氧六环", 74: "二甲硫醚", 75: "乙硫醇", 76: "二乙硫醚",
  77: "甲醇", 78: "乙醇", 79: "丙醇", 80: "异丙醇", 81: "丁醇",
  82: "异丁醇", 83: "仲丁醇", 84: "叔丁醇", 85: "戊醇", 86: "异戊醇",
  87: "甲硫醇",
  88: "乙硫醇(可燃)", 89: "甲醛(可燃)", 90: "乙醛", 91: "丙烯醛",
  92: "丙酮", 93: "丁酮", 94: "甲基异丁基酮",
  95: "甲酸甲酯", 96: "甲酸乙酯", 97: "乙酸甲酯", 98: "乙酸乙酯",
  99: "乙酸丙酯", 100: "乙酸丁酯", 101: "乙酸异丁酯", 102: "乙酸戊酯",
  103: "乙酸异戊酯", 104: "丙烯酸甲酯", 105: "丙烯酸乙酯",
  106: "甲胺", 107: "乙胺", 108: "二甲胺", 109: "二乙胺", 110: "三甲胺",
  111: "三乙胺", 112: "异丙胺", 113: "丁胺", 114: "乙二胺",
  115: "异辛烷", 116: "二氯丙烯",
  117: "氯甲烷", 118: "二氯甲烷", 119: "四氢噻吩", 120: "呋喃",
  121: "丙烯腈(可燃)", 122: "环氧乙烷(可燃)",
  128: "煤气",
  129: "一氧化碳", 130: "氧气",
  131: "臭氧", 132: "氨气", 133: "氯气", 134: "氟气", 135: "氟利昂",
  136: "光气(碳酰氯)", 137: "乙酰氯", 138: "乙腈", 139: "丙烯腈",
  140: "氯化氰", 141: "甲醛", 142: "甲酸", 143: "硝酸", 144: "盐酸",
  145: "氢溴酸", 146: "乙胺(可燃)", 147: "二丁胺", 148: "苯胺",
  149: "苯酚", 150: "苯(可燃)", 151: "环氧乙烷",
  152: "丙烯酸", 153: "溴甲烷", 154: "二氧化氮", 155: "一氧化氮",
  156: "二氧化硫", 157: "硫化氢", 158: "磷化氢(膦)", 159: "砷化氢",
  160: "锗烷", 161: "乙硼烷", 162: "硅烷", 163: "氯化氢",
  164: "氟化氢", 165: "溴化氢", 166: "二氧化氯",
  167: "过氧化氢", 168: "碳酰氟", 169: "氰化氢",
  170: "甲醇(有毒)", 171: "乙醇(有毒)",
  172: "二硫化碳", 173: "羰基硫", 174: "氯乙烯",
  175: "四氟化硫", 176: "三氟化氮", 177: "三氟化硼", 178: "六氟化硫",
  179: "六氟化钨", 180: "三氯化硼", 181: "五氟化溴",
  182: "五氟化碘", 183: "三氟化氯", 184: "四氟乙烯",
  185: "全氟异丁烯", 186: "乙烯基三氯硅烷", 187: "三甲基氯硅烷",
  188: "二甲基二氯硅烷", 189: "甲基三氯硅烷",
  190: "三氯硅烷", 191: "四氯化硅", 192: "二氯硅烷",
  193: "异氰酸甲酯", 194: "甲基肼", 195: "丙烯醛(有毒)",
  196: "二甲基甲酰胺(DMF)", 197: "四氢噻吩(有毒)", 198: "甲苯(有毒)",
  199: "二甲苯(有毒)", 200: "乙苯(有毒)",
  201: "二氯环己烷", 202: "异辛醇", 203: "三甲基苯",
  204: "醋酸异丙酯", 205: "乙酸仲丁酯", 206: "丙二醇甲醚",
  207: "丙二醇甲醚醋酸酯", 208: "甲基丙烯酸甲酯",
  209: "甲基丙烯酸丁酯", 210: "丁酮肟",
  211: "二异丁基酮", 212: "乙酰丙酮", 213: "环己酮",
  229: "氯气(小量程)", 230: "氨气(小量程)", 231: "苯(小量程)",
  232: "溴甲烷(小量程)", 233: "环氧乙烷(小量程)", 234: "四氢噻吩(小量程)", 235: "溴(小量程)",
  251: "其他有毒气体(大量程)", 252: "其他可燃气体", 253: "其他氧气/氮气", 254: "其他有毒气体(小量程)"
};

// ═══════════════════════════════════════════
//  探测器状态位 (8位)
// ═══════════════════════════════════════════

var DETECTOR_BITS = [
  "低限报警", "高限报警", "故障", "屏蔽/预留",
  "启动", "反馈", "预留", "预留"
];

// ═══════════════════════════════════════════
//  控制器状态位 (16位)
// ═══════════════════════════════════════════

var MONITOR_BITS = [
  "CANBUS网络故障", "CRT连接故障", "预留串口故障", "网络通讯故障",
  "回路1开路故障", "回路1短路故障", "回路1主从通讯故障",
  "回路2开路故障", "回路2短路故障", "回路2主从通讯故障",
  "回路3开路故障", "回路3短路故障", "回路3主从通讯故障",
  "回路4开路故障", "回路4短路故障", "回路4主从通讯故障"
];

// ═══════════════════════════════════════════
//  外控电源状态
// ═══════════════════════════════════════════

var EXTER_POWER = {
  0x30: "主电正常, 备电正常",
  0x70: "主电正常, 备电正常(开启)",
  0x20: "主电欠压, 备电正常",
  0x60: "主电欠压, 备电正常(开启)",
  0x33: "主电正常, 备电开路",
  0x73: "主电正常, 备电开路(开启)",
  0x23: "主电欠压, 备电开路",
  0x63: "主电欠压, 备电开路(开启)",
  0x31: "主电正常, 备电短路",
  0x71: "主电正常, 备电短路(开启)",
  0x21: "主电欠压, 备电短路",
  0x61: "主电欠压, 备电短路(开启)",
  0x10: "主电掉电, 备电正常",
  0x50: "主电掉电, 备电正常(开启)",
  0x11: "主电掉电, 备电欠压",
  0x51: "主电掉电, 备电欠压(开启)"
};

// ═══════════════════════════════════════════
//  寄存器地址映射
// ═══════════════════════════════════════════

var REGISTER_MAP = [
  { start: 0x0000, end: 0x0000, name: "回路1-2布点数", parser: "placement" },
  { start: 0x0001, end: 0x0001, name: "回路3-4布点数", parser: "placement" },
  { start: 0x0002, end: 0x00F9, name: "回路1属性单位", parser: "attrUnit", circuit: 1 },
  { start: 0x00FA, end: 0x01F1, name: "回路2属性单位", parser: "attrUnit", circuit: 2 },
  { start: 0x01F2, end: 0x02E9, name: "回路3属性单位", parser: "attrUnit", circuit: 3 },
  { start: 0x02EA, end: 0x03E1, name: "回路4属性单位", parser: "attrUnit", circuit: 4 },
  { start: 0x03E2, end: 0x04D9, name: "回路1低限报警值", parser: "lowAlarm", circuit: 1 },
  { start: 0x04DA, end: 0x05D1, name: "回路2低限报警值", parser: "lowAlarm", circuit: 2 },
  { start: 0x05D2, end: 0x06C9, name: "回路3低限报警值", parser: "lowAlarm", circuit: 3 },
  { start: 0x06CA, end: 0x07C1, name: "回路4低限报警值", parser: "lowAlarm", circuit: 4 },
  { start: 0x07C2, end: 0x08B9, name: "回路1探测器状态", parser: "probeStatus", circuit: 1 },
  { start: 0x08BA, end: 0x09B1, name: "回路2探测器状态", parser: "probeStatus", circuit: 2 },
  { start: 0x09B2, end: 0x0AA9, name: "回路3探测器状态", parser: "probeStatus", circuit: 3 },
  { start: 0x0AAA, end: 0x0BA1, name: "回路4探测器状态", parser: "probeStatus", circuit: 4 },
  { start: 0x0BA2, end: 0x0C99, name: "回路1探测器浓度", parser: "detector", circuit: 1 },
  { start: 0x0C9A, end: 0x0D91, name: "回路2探测器浓度", parser: "detector", circuit: 2 },
  { start: 0x0D92, end: 0x0E89, name: "回路3探测器浓度", parser: "detector", circuit: 3 },
  { start: 0x0E8A, end: 0x0F81, name: "回路4探测器浓度", parser: "detector", circuit: 4 },
  { start: 0x0F82, end: 0x0F83, name: "回路1外控电源状态", parser: "ecps", circuit: 1 },
  { start: 0x0F84, end: 0x0F85, name: "回路2外控电源状态", parser: "ecps", circuit: 2 },
  { start: 0x0F86, end: 0x0F87, name: "回路3外控电源状态", parser: "ecps", circuit: 3 },
  { start: 0x0F88, end: 0x0F89, name: "回路4外控电源状态", parser: "ecps", circuit: 4 },
  { start: 0x0F8A, end: 0x0F8A, name: "控制器状态", parser: "controlStatus" }
];

function findRegister(addr) {
  for (var i = 0; i < REGISTER_MAP.length; i++) {
    var r = REGISTER_MAP[i];
    if (r.start === addr || (addr >= r.start && addr <= r.end)) {
      return r;
    }
  }
  return null;
}

// ═══════════════════════════════════════════
//  位图解析
// ═══════════════════════════════════════════

function parseDetectorBits(byte) {
  var results = [];
  for (var i = 0; i < 8; i++) {
    if (((byte >> i) & 1) === 1) {
      results.push(DETECTOR_BITS[i]);
    }
  }
  return results;
}

function parseMonitorBits(data) {
  var val = (data[0] & 0xFF) | ((data[1] & 0xFF) << 8);
  var results = [];
  for (var i = 0; i < 16; i++) {
    if (((val >> i) & 1) === 1) {
      results.push(MONITOR_BITS[i]);
    }
  }
  return results;
}

// ═══════════════════════════════════════════
//  数据区解析(按寄存器类型分发)
// ═══════════════════════════════════════════

function parseDataByRegister(regInfo, data, fields) {
  var parser = regInfo.parser;
  var circuit = regInfo.circuit || 0;

  if (parser === "placement") {
    // 每字节一个回路的布点数
    for (var i = 0; i < data.length; i++) {
      var circuitNo = (regInfo.start === 0x0000) ? i + 1 : i + 3;
      var pointCount = data[i] & 0xFF;
      fields.push({
        key: "placement_c" + circuitNo, label: "回路" + circuitNo + " 布点数",
        value: "" + pointCount + " 个",
        group: "配置信息"
      });
    }
  } else if (parser === "attrUnit") {
    // 每2字节: [单位类型, 气体类型]
    for (var i = 0; i < data.length - 1; i += 2) {
      var pointNo = Math.floor(i / 2) + 1;
      var unitCode = data[i] & 0xFF;
      var gasCode = data[i + 1] & 0xFF;
      var unitInfo = UNIT_TYPES[unitCode] || { unit: "?", name: "未知", rate: 1 };
      var gasName = GAS_TYPES[gasCode] || "未知气体(" + gasCode + ")";
      fields.push({
        key: "attr_c" + circuit + "_p" + pointNo,
        label: "回路" + circuit + "-点" + pointNo,
        value: gasName + " [" + unitInfo.unit + "]",
        group: "回路" + circuit + " 属性",
        tooltip: "单位编码: " + unitCode + " (" + unitInfo.name + "), 气体编码: " + gasCode
      });
    }
  } else if (parser === "lowAlarm") {
    // 每2字节: 高位+低位, 值 = (high*256+low) / 10
    for (var i = 0; i < data.length - 1; i += 2) {
      var pointNo = Math.floor(i / 2) + 1;
      var val = ((data[i] & 0xFF) * 256 + (data[i + 1] & 0xFF)) / 10;
      fields.push({
        key: "lowAlarm_c" + circuit + "_p" + pointNo,
        label: "回路" + circuit + "-点" + pointNo + " 低限值",
        value: val.toFixed(1),
        group: "回路" + circuit + " 低限报警"
      });
    }
  } else if (parser === "probeStatus") {
    // 每2字节: [高字节(保留), 低字节(状态位)]
    for (var i = 0; i < data.length - 1; i += 2) {
      var pointNo = Math.floor(i / 2) + 1;
      var statusByte = data[i + 1] & 0xFF;
      var statusList = parseDetectorBits(statusByte);
      var statusStr = statusList.length > 0 ? statusList.join(", ") : "正常";
      var statusColor = statusList.length > 0 ? "red" : "emerald";
      fields.push({
        key: "status_c" + circuit + "_p" + pointNo,
        label: "回路" + circuit + "-点" + pointNo + " 状态",
        value: statusStr,
        group: "回路" + circuit + " 探测器状态",
        uiType: "status-dot", color: statusColor
      });
    }
  } else if (parser === "detector") {
    // 每2字节: 浓度值 = (high*256+low) / 10
    for (var i = 0; i < data.length - 1; i += 2) {
      var pointNo = Math.floor(i / 2) + 1;
      var val = ((data[i] & 0xFF) * 256 + (data[i + 1] & 0xFF)) / 10;
      fields.push({
        key: "conc_c" + circuit + "_p" + pointNo,
        label: "回路" + circuit + "-点" + pointNo + " 浓度",
        value: val.toFixed(1),
        group: "回路" + circuit + " 探测器浓度"
      });
    }
  } else if (parser === "ecps") {
    // 每字节: 外控电源状态码
    for (var i = 0; i < data.length; i++) {
      var code = data[i] & 0xFF;
      var statusName = EXTER_POWER[code] || "未知状态(0x" + padHex(code, 2) + ")";
      var isNormal = (code === 0x30 || code === 0x70);
      fields.push({
        key: "ecps_c" + circuit + "_" + i,
        label: "回路" + circuit + " 外控电源" + (i + 1),
        value: statusName,
        group: "外控电源状态",
        uiType: "status-dot", color: isNormal ? "emerald" : "amber"
      });
    }
  } else if (parser === "controlStatus") {
    // 2字节: 控制器16位状态
    if (data.length >= 2) {
      var faults = parseMonitorBits(data);
      var faultStr = faults.length > 0 ? faults.join(", ") : "正常";
      fields.push({
        key: "ctrlStatus", label: "控制器状态",
        value: faultStr,
        group: "控制器状态",
        uiType: faults.length > 0 ? "status-dot" : "status-dot",
        color: faults.length > 0 ? "red" : "emerald",
        isKeyInfo: true
      });
      // 展示各位详情
      var val = (data[0] & 0xFF) | ((data[1] & 0xFF) << 8);
      for (var bit = 0; bit < 16; bit++) {
        var isSet = ((val >> bit) & 1) === 1;
        if (isSet) {
          fields.push({
            key: "ctrlBit" + bit, label: "Bit" + bit,
            value: MONITOR_BITS[bit],
            group: "控制器状态", uiType: "status-dot", color: "red"
          });
        }
      }
    }
  }
}

// ═══════════════════════════════════════════
//  帧类型检测
// ═══════════════════════════════════════════

function detectFrameType(bytes) {
  if (bytes.length < 5) return "unknown";
  var funcCode = bytes[1];
  if (funcCode === 0x03) {
    if (bytes.length === 8) return "request";  // 请求帧: 地址+功能码+起始寄存器2B+读取数量2B+CRC2B
    if (bytes.length > 5) return "response";   // 响应帧: 地址+功能码+字节数+数据+CRC
  }
  return "unknown";
}

// ═══════════════════════════════════════════
//  解析器入口
// ═══════════════════════════════════════════

function parse(rawData) {
  try {
    var hex = rawData.replace(/\s+/g, "").toUpperCase();
    var bytes = hexToBytes(hex);

    if (bytes.length < 5) {
      return { success: false, protocolName: "SFJK200", summary: "",
               fields: [], error: "数据长度不足：最少需要5字节" };
    }

    var fields = [];
    var frameType = detectFrameType(bytes);

    // 地址
    var address = bytes[0] & 0xFF;
    fields.push({ key: "address", label: "从机地址", value: "" + address, group: "帧头", isKeyInfo: true });

    // 功能码
    var funcCode = bytes[1] & 0xFF;
    var funcName = funcCode === 0x03 ? "读保持寄存器" : "未知(0x" + padHex(funcCode, 2) + ")";
    fields.push({
      key: "funcCode", label: "功能码",
      value: "0x" + padHex(funcCode, 2) + " (" + funcName + ")",
      group: "帧头", uiType: "badge", color: "blue", isKeyInfo: true
    });

    if (frameType === "request") {
      // 请求帧解析
      var startReg = readUint16BE(bytes, 2);
      var readCount = readUint16BE(bytes, 4);
      var regInfo = findRegister(startReg);

      fields.push({
        key: "frameType", label: "帧类型",
        value: "请求帧 (Modbus Read)",
        group: "帧头", uiType: "badge", color: "blue"
      });
      fields.push({
        key: "startReg", label: "起始寄存器地址",
        value: "0x" + padHex(startReg, 4) + (regInfo ? " (" + regInfo.name + ")" : ""),
        group: "数据区", isKeyInfo: true
      });
      fields.push({
        key: "readCount", label: "读取寄存器数量",
        value: "" + readCount,
        group: "数据区"
      });

      // CRC校验
      var recvCrc = readUint16LE(bytes, 6);
      var calcCrc = crc16Modbus(bytes.slice(0, 6));
      var crcOk = recvCrc === calcCrc;
      fields.push({
        key: "crc", label: "CRC-16 Modbus",
        value: padHex(recvCrc, 4) + (crcOk ? " \u2713 校验通过" : " \u2717 校验失败 (预期 " + padHex(calcCrc, 4) + ")"),
        group: "帧尾", uiType: "status-dot", color: crcOk ? "emerald" : "red", isKeyInfo: true
      });

      var summary = "SFJK200 请求 [地址:" + address + "] " + (regInfo ? regInfo.name : "寄存器0x" + padHex(startReg, 4));

      return {
        success: true, protocolName: "SFJK200", summary: summary,
        fields: fields, layout: buildLayout(fields)
      };

    } else if (frameType === "response") {
      // 响应帧解析
      var dataLen = bytes[2] & 0xFF;
      fields.push({
        key: "frameType", label: "帧类型",
        value: "响应帧 (Modbus Response)",
        group: "帧头", uiType: "badge", color: "emerald"
      });
      fields.push({
        key: "dataLen", label: "数据字节数",
        value: "" + dataLen + " 字节",
        group: "帧头"
      });

      // 数据区
      var dataStart = 3;
      var dataEnd = dataStart + dataLen;
      if (dataEnd > bytes.length - 2) dataEnd = bytes.length - 2;
      var data = bytes.slice(dataStart, dataEnd);

      // 显示原始数据
      fields.push({
        key: "rawData", label: "原始数据",
        value: bytesToHex(data),
        group: "数据区", uiType: "code"
      });

      // 注意: 响应帧不包含寄存器地址信息，需要用户上下文或手动指定
      // 这里展示通用的数据字解析
      if (data.length >= 2) {
        fields.push({
          key: "regCount", label: "寄存器数量",
          value: "" + Math.floor(data.length / 2),
          group: "数据区"
        });

        // 展示每个寄存器的值
        for (var i = 0; i < data.length - 1; i += 2) {
          var regVal = readUint16BE(data, i);
          var regIdx = Math.floor(i / 2) + 1;
          fields.push({
            key: "reg_" + regIdx, label: "寄存器 #" + regIdx,
            value: "" + regVal + " (0x" + padHex(regVal, 4) + ")",
            group: "寄存器数据"
          });
        }
      }

      // CRC校验
      if (bytes.length >= dataEnd + 2) {
        var recvCrc = readUint16LE(bytes, dataEnd);
        var calcCrc = crc16Modbus(bytes.slice(0, dataEnd));
        var crcOk = recvCrc === calcCrc;
        fields.push({
          key: "crc", label: "CRC-16 Modbus",
          value: padHex(recvCrc, 4) + (crcOk ? " \u2713 校验通过" : " \u2717 校验失败 (预期 " + padHex(calcCrc, 4) + ")"),
          group: "帧尾", uiType: "status-dot", color: crcOk ? "emerald" : "red", isKeyInfo: true
        });
      }

      var summary = "SFJK200 响应 [地址:" + address + "] " + dataLen + "字节数据";

      return {
        success: true, protocolName: "SFJK200", summary: summary,
        fields: fields, layout: buildLayout(fields)
      };

    } else {
      // 尝试按寄存器地址解析(用户可能提供了带寄存器上下文的数据)
      fields.push({
        key: "rawData", label: "原始数据",
        value: hex,
        group: "数据区", uiType: "code"
      });

      return {
        success: true, protocolName: "SFJK200",
        summary: "SFJK200 数据 [地址:" + address + "]",
        fields: fields, layout: buildLayout(fields)
      };
    }

  } catch (e) {
    return {
      success: false, protocolName: "SFJK200", summary: "",
      fields: [], error: "解析异常: " + e.toString()
    };
  }
}

// ═══════════════════════════════════════════
//  Layout 布局生成
// ═══════════════════════════════════════════

function buildLayout(fields) {
  var sections = [];
  var groupMap = {};
  var groupOrder = [];
  for (var i = 0; i < fields.length; i++) {
    var f = fields[i];
    var g = f.group || "__ungrouped";
    if (!groupMap[g]) { groupMap[g] = []; groupOrder.push(g); }
    groupMap[g].push(f);
  }

  var styleMap = {
    "帧头": { style: "key-value", color: "blue" },
    "数据区": { style: "key-value", color: "teal" },
    "寄存器数据": { style: "key-value", color: "cyan" },
    "配置信息": { style: "key-value", color: "teal" },
    "外控电源状态": { style: "key-value", color: "amber" },
    "控制器状态": { style: "key-value", color: "red" },
    "帧尾": { style: "key-value", color: "slate" }
  };

  for (var gi = 0; gi < groupOrder.length; gi++) {
    var group = groupOrder[gi];
    var gFields = groupMap[group];
    var mapping = styleMap[group] || { style: "key-value", color: "indigo" };
    var keys = [];
    for (var ki = 0; ki < gFields.length; ki++) keys.push(gFields[ki].key);
    sections.push({ title: group, style: mapping.style, color: mapping.color, fieldKeys: keys });
  }

  return { sections: sections };
}

// ═══════════════════════════════════════════
//  报文生成器 (生成 Modbus 读请求帧)
// ═══════════════════════════════════════════

function generate(params) {
  try {
    var address = parseInt(params.address || "1");
    var funcCode = parseInt(params.funcCode || "3");
    var startReg = parseInt(params.startRegister || "0", 16);
    var readCount = parseInt(params.readCount || "1");

    var packet = [];

    // 地址
    packet.push(address & 0xFF);
    // 功能码
    packet.push(funcCode & 0xFF);
    // 起始寄存器(大端)
    packet.push((startReg >> 8) & 0xFF);
    packet.push(startReg & 0xFF);
    // 读取数量(大端)
    packet.push((readCount >> 8) & 0xFF);
    packet.push(readCount & 0xFF);
    // CRC-16(小端)
    var crc = crc16Modbus(packet);
    packet.push(crc & 0xFF);
    packet.push((crc >> 8) & 0xFF);

    var message = bytesToHex(packet);

    return {
      success: true,
      protocolName: "SFJK200",
      message: message,
      formatted: message.replace(/(.{2})/g, "$1 ").trim()
    };

  } catch (e) {
    return {
      success: false,
      protocolName: "SFJK200",
      message: "",
      error: "生成异常: " + e.toString()
    };
  }
}
