/**
 * JBF-293K 通讯接口卡 RS232/485 通讯协议完整解析器 + 报文生成器
 *
 * 完全支持 JBF293K 火灾报警控制器的通讯协议
 * 适用于消防控制器、气体灭火、防火门、电气火灾等设备通讯
 *
 * 帧格式:
 *   [0x82(起始)] [D1-D12(数据,每字段2字节ASCII编码)] [累加和/CRC(2字节)] [0x83(结束)]
 *   每个数据字节拆分为高低半字节，各加0x30编码传输
 *
 * 扩展帧(电气火灾D5=0xFF):
 *   [0x82] [D1-D12] [累加和2B] [D13-D16扩展数据] [CRC8 2B] [0x83]
 */

// ═══════════════════════════════════════════
//  工具函数
// ═══════════════════════════════════════════

function hexToBytes(hex) {
  hex = hex.replace(/\s+/g, "");
  var bytes = [];
  for (var i = 0; i < hex.length; i += 2) {
    bytes.push(parseInt(hex.substring(i, i + 2), 16));
  }
  return bytes;
}

function bytesToHex(bytes) {
  var r = "";
  for (var i = 0; i < bytes.length; i++) {
    var h = bytes[i].toString(16).toUpperCase();
    if (h.length < 2) h = "0" + h;
    r += h;
  }
  return r;
}

function padHex(val, len) {
  var s = val.toString(16).toUpperCase();
  while (s.length < len) s = "0" + s;
  return s;
}

// 解码一个2字节ASCII编码的数据字(去0x30掩码): [(high-0x30)<<4 | (low-0x30)]
function decodeWord(b1, b2) {
  return ((b1 - 0x30) & 0x0F) << 4 | ((b2 - 0x30) & 0x0F);
}

// CRC8-MAXIM 算法
function crc8Maxim(data) {
  var crc = 0;
  for (var i = 0; i < data.length; i++) {
    crc = crc ^ (data[i] & 0xFF);
    for (var j = 0; j < 8; j++) {
      if ((crc & 1) !== 0) {
        crc = ((crc >> 1) ^ 0x8C) & 0xFF;
      } else {
        crc = (crc >> 1) & 0xFF;
      }
    }
  }
  return crc & 0xFF;
}

// ═══════════════════════════════════════════
//  命令/报警类型定义
// ═══════════════════════════════════════════

var ALARM_MAP = {};

// 常规报警
var ALARM_DEFS = [
  { codes: [0x00, 0x69], name: "控制器心跳", parser: "heart" },
  { codes: [0x09], name: "控制器正常", parser: "version" },
  { codes: [0xEF], name: "控制器故障", parser: "version" },
  { codes: [0x01], name: "控制器复位", parser: "version" },
  { codes: [0x0B], name: "控制器消音", parser: "version" },
  { codes: [0x80, 0x0A], name: "火警", parser: "common" },
  { codes: [0x81], name: "故障", parser: "common" },
  { codes: [0x82], name: "故障恢复", parser: "common" },
  { codes: [0x87], name: "回路故障", parser: "common" },
  { codes: [0x88], name: "回路故障恢复", parser: "common" },
  { codes: [0x83], name: "自动启动", parser: "common" },
  { codes: [0x84], name: "自动停止", parser: "common" },
  { codes: [0x90], name: "手动启动", parser: "common" },
  { codes: [0x91], name: "手动停止", parser: "common" },
  { codes: [0x85], name: "设备回答", parser: "common" },
  { codes: [0x86], name: "回答撤销", parser: "common" },
  { codes: [0x98], name: "部件隔离", parser: "common" },
  { codes: [0x97], name: "部件隔离撤销", parser: "common" },
  { codes: [0x8C], name: "监管报警", parser: "common" },
  { codes: [0x8D], name: "监管报警撤销", parser: "common" },
  { codes: [0x8B], name: "模拟报警", parser: "simulation" },
  // 多线盘
  { codes: [0x51], name: "多线手动启动", parser: "multiline", circuit: 0xF2 },
  { codes: [0x52], name: "多线手动停止", parser: "multiline", circuit: 0xF2 },
  { codes: [0x53], name: "多线回答", parser: "multiline", circuit: 0xF2 },
  { codes: [0x54], name: "多线停止回答", parser: "multiline", circuit: 0xF2 },
  { codes: [0x55], name: "多线自动启动", parser: "multiline", circuit: 0xF2 },
  { codes: [0x56], name: "多线自动停止", parser: "multiline", circuit: 0xF2 },
  { codes: [0x57], name: "多线自动启动延时", parser: "multiline", circuit: 0xF2 },
  { codes: [0x58], name: "多线应答缺失", parser: "multiline", circuit: 0xF2 },
  { codes: [0x59], name: "多线线路故障", parser: "multiline", circuit: 0xF2 },
  { codes: [0x5A], name: "多线线路故障恢复", parser: "multiline", circuit: 0xF2 }
];

for (var a = 0; a < ALARM_DEFS.length; a++) {
  var def = ALARM_DEFS[a];
  for (var c = 0; c < def.codes.length; c++) {
    ALARM_MAP[def.codes[c]] = def;
  }
}

// 气体/喷洒系统
var SPRAY_MSG_MAP = {
  0x01: "气体线路故障", 0x02: "气体线路故障恢复",
  0x03: "气体喷洒应答", 0x04: "气体喷洒应答撤销",
  0x05: "声光启动", 0x06: "声光停止",
  0x07: "相关设备动作", 0x08: "相关设备动作停止",
  0x09: "防火区启动", 0x0A: "防火区停止",
  0x0B: "喷洒启动", 0x0C: "延时启动",
  0x0E: "远程停止动作撤销",
  0x80: "故障", 0x90: "恢复"
};

// 防火门部件类型
var DOOR_TYPES = { 1: "单常开", 2: "单常闭", 3: "双常开", 4: "双常闭" };

// 防火门状态
var DOOR_STATUS = {
  1: "故障", 2: "故障撤销", 3: "延时关闭",
  4: "正在关闭(自动)", 5: "正在关闭消息撤销(自动)",
  6: "正在关闭(手动)", 7: "正在关闭消息撤销(手动)",
  8: "成功关闭(由于启动)", 9: "成功关闭消息撤销",
  0xA: "屏蔽", 0xB: "屏蔽撤销"
};

// 电气火灾探测器类型
var ELE_FIRE_TYPES = {
  1: { name: "全部探测器", factor: 0, unit: "", minus: false },
  2: { name: "剩余电流探测器", factor: 1, unit: "mA", minus: false },
  3: { name: "温度探测器", factor: 1, unit: "\u2103", minus: true },
  4: { name: "故障电弧探测器", factor: 0, unit: "", minus: false },
  5: { name: "过电流探测器", factor: 2, unit: "A", minus: false },
  6: { name: "脱扣继电器", factor: 0, unit: "", minus: false }
};

// 电气火灾状态
var ELE_FIRE_STATUS = {
  1: "报警", 2: "故障", 3: "故障撤销",
  4: "脱扣动作(自动)", 5: "脱扣停止(自动)",
  6: "脱扣动作(手动)", 7: "脱扣停止(手动)",
  8: "屏蔽", 9: "屏蔽撤销"
};

// ═══════════════════════════════════════════
//  数据解析器
// ═══════════════════════════════════════════

function parseHeartData(words, fields) {
  fields.push({ key: "machineNo", label: "机器号", value: "" + words[1], group: "数据区" });
}

function parseVersionData(words, fields) {
  fields.push({ key: "version", label: "版本号", value: words[1] + "." + words[2], group: "数据区" });
}

function parseCommonData(words, fields) {
  fields.push({ key: "machineNo", label: "机器号", value: "" + words[1], group: "数据区" });
  fields.push({ key: "circuit", label: "回路号", value: "" + words[2], group: "数据区" });
  fields.push({ key: "address", label: "地址", value: "" + words[3], group: "数据区" });
}

function parseMultilineData(words, fields) {
  fields.push({ key: "machineNo", label: "机器号", value: "" + words[1], group: "数据区" });
  var part = words[3];
  // 计算盘号和专线号: part = (disk-1)*8 + line
  var disk = 0, line = 0;
  for (var i = 1; i <= 31; i++) {
    for (var j = 1; j <= 8; j++) {
      if ((i - 1) * 8 + j === part) { disk = i; line = j; break; }
    }
    if (disk > 0) break;
  }
  fields.push({ key: "part", label: "编号", value: "" + part, group: "数据区" });
  if (disk > 0) {
    fields.push({ key: "disk", label: "盘号", value: "" + disk, group: "数据区" });
    fields.push({ key: "line", label: "专线号", value: "" + line, group: "数据区" });
  }
}

function parseSimulationData(words, fields) {
  fields.push({ key: "machineNo", label: "机器号", value: "" + words[1], group: "数据区" });
  fields.push({ key: "circuit", label: "回路号", value: "" + (words[2] - 1) + " (原始值: " + words[2] + ")", group: "数据区" });
  fields.push({ key: "address", label: "地址", value: "" + words[3], group: "数据区" });
}

function parseSprayData(orderType, words, fields) {
  fields.push({ key: "machineNo", label: "机器号", value: "" + words[1], group: "数据区" });
  var msgType = words[2];
  var msgName = SPRAY_MSG_MAP[msgType] || "未知消息(0x" + padHex(msgType, 2) + ")";

  if (orderType === 0xFA) {
    // MessageSprayParser: 计算盘号和区号
    fields.push({ key: "message", label: "消息类型", value: msgName, group: "数据区", uiType: "badge", color: "purple" });
    var part = words[3];
    var disk = 0, district = 0;
    for (var i = 1; i <= 63; i++) {
      for (var j = 1; j <= 4; j++) {
        if ((i - 1) * 4 + j === part) { disk = i; district = j; break; }
      }
      if (disk > 0) break;
    }
    fields.push({ key: "part", label: "编号", value: "" + part, group: "数据区" });
    if (disk > 0) {
      fields.push({ key: "disk", label: "盘号", value: "" + disk, group: "数据区" });
      fields.push({ key: "district", label: "区号", value: "" + district, group: "数据区" });
    }
  } else if (orderType === 0x70) {
    // BoardSprayParser: 板号
    fields.push({ key: "message", label: "消息类型", value: msgName, group: "数据区", uiType: "badge", color: "purple" });
    fields.push({ key: "boardNumber", label: "板号", value: "" + words[3], group: "数据区" });
  } else {
    // CommonSprayParser: 主电/备电
    fields.push({ key: "message", label: "消息类型", value: msgName, group: "数据区", uiType: "badge", color: "purple" });
  }
}

function parseFireDoorData(words, fields) {
  fields.push({ key: "machineNo", label: "机器号", value: "" + words[1], group: "数据区" });
  fields.push({ key: "circuit", label: "回路号", value: "" + words[2], group: "数据区" });
  fields.push({ key: "address", label: "地址", value: "" + words[3], group: "数据区" });
  var d5 = words[4];
  var doorType = d5 & 0x0F;
  var doorStatus = (d5 >> 4) & 0x0F;
  var typeName = DOOR_TYPES[doorType] || "未知类型(" + doorType + ")";
  var statusName = DOOR_STATUS[doorStatus] || "未知状态(" + doorStatus + ")";
  fields.push({ key: "doorType", label: "防火门类型", value: typeName, group: "数据区", uiType: "badge", color: "blue" });
  fields.push({ key: "doorStatus", label: "防火门状态", value: statusName, group: "数据区", uiType: "badge", color: doorStatus <= 2 ? "amber" : doorStatus <= 7 ? "blue" : doorStatus <= 9 ? "emerald" : "purple" });
}

function parseEleFireData(words, isExtended, extWords, fields) {
  fields.push({ key: "machineNo", label: "机器号", value: "" + words[1], group: "数据区" });
  fields.push({ key: "circuit", label: "回路号", value: "" + words[2], group: "数据区" });
  fields.push({ key: "address", label: "地址", value: "" + words[3], group: "数据区" });

  if (!isExtended) {
    // 标准模式: D5低4位=类型, 高4位=状态
    var d5 = words[4];
    var eleType = d5 & 0x0F;
    var eleStatus = (d5 >> 4) & 0x0F;
    var typeInfo = ELE_FIRE_TYPES[eleType] || { name: "未知(" + eleType + ")", factor: 0, unit: "" };
    var statusName = ELE_FIRE_STATUS[eleStatus] || "未知状态(" + eleStatus + ")";
    fields.push({ key: "eleType", label: "探测器类型", value: typeInfo.name, group: "数据区", uiType: "badge", color: "blue" });
    fields.push({ key: "eleStatus", label: "探测器状态", value: statusName, group: "数据区", uiType: "badge", color: eleStatus === 1 ? "red" : eleStatus === 2 ? "amber" : "emerald" });
  } else {
    // 扩展模式: D5=0xFF, D13=类型/状态, D14=通道, D15+D16=报警值
    fields.push({ key: "extFlag", label: "扩展标志", value: "0xFF (扩展数据模式)", group: "数据区", uiType: "badge", color: "purple" });

    if (extWords && extWords.length >= 4) {
      var d13 = extWords[0];
      var eleType2 = d13 & 0x0F;
      var eleStatus2 = (d13 >> 4) & 0x0F;
      var typeInfo2 = ELE_FIRE_TYPES[eleType2] || { name: "未知(" + eleType2 + ")", factor: 0, unit: "", minus: false };
      var statusName2 = ELE_FIRE_STATUS[eleStatus2] || "未知状态(" + eleStatus2 + ")";
      fields.push({ key: "eleType", label: "探测器类型", value: typeInfo2.name, group: "扩展数据", uiType: "badge", color: "blue" });
      fields.push({ key: "eleStatus", label: "探测器状态", value: statusName2, group: "扩展数据", uiType: "badge", color: eleStatus2 === 1 ? "red" : eleStatus2 === 2 ? "amber" : "emerald" });
      fields.push({ key: "sensorChannel", label: "传感器通道", value: "" + extWords[1], group: "扩展数据" });

      // 报警值: (low | (high << 8)) / 10^factor
      var low = extWords[2] & 0xFF;
      var high = extWords[3] & 0xFF;
      var rawVal = low | (high << 8);
      var factor = typeInfo2.factor;
      var divisor = 1;
      for (var f = 0; f < factor; f++) divisor *= 10;
      var alarmVal = rawVal / divisor;
      // 负值检查(仅温度)
      if (typeInfo2.minus && high >= 128) {
        alarmVal = -alarmVal;
      }
      var valDisplay = "" + alarmVal;
      if (typeInfo2.unit) valDisplay += " " + typeInfo2.unit;
      fields.push({ key: "alarmValue", label: "报警值", value: valDisplay, unit: typeInfo2.unit, group: "扩展数据", isKeyInfo: true });
    }
  }
}

// ═══════════════════════════════════════════
//  时间解析
// ═══════════════════════════════════════════

function parseTime(words, startIdx) {
  if (startIdx + 6 > words.length) return "时间数据不足";
  var year = 2000 + words[startIdx];
  var month = words[startIdx + 1];
  var day = words[startIdx + 2];
  var hour = words[startIdx + 3];
  var min = words[startIdx + 4];
  var sec = words[startIdx + 5];
  return year + "-" + pad2(month) + "-" + pad2(day) + " " +
         pad2(hour) + ":" + pad2(min) + ":" + pad2(sec);
}

function pad2(n) {
  return n < 10 ? "0" + n : "" + n;
}

// ═══════════════════════════════════════════
//  解析器入口
// ═══════════════════════════════════════════

function parse(rawData) {
  try {
    var hex = rawData.replace(/\s+/g, "").toUpperCase();
    var bytes = hexToBytes(hex);

    // 基本校验
    if (bytes.length < 3) {
      return { success: false, protocolName: "JBF293K", summary: "",
               fields: [], error: "数据长度不足" };
    }
    if (bytes[0] !== 0x82) {
      return { success: false, protocolName: "JBF293K", summary: "",
               fields: [], error: "非 JBF293K 报文：缺少起始符 0x82" };
    }

    var fields = [];

    // 起始符
    fields.push({ key: "header", label: "起始符", value: "0x82", group: "帧头", uiType: "code" });

    // 解码数据字: 每2字节为一个数据字
    var dataBytes = bytes.slice(1); // 去掉起始符
    // 找结束符0x83
    var footerIdx = -1;
    for (var fi = dataBytes.length - 1; fi >= 0; fi--) {
      if (dataBytes[fi] === 0x83) { footerIdx = fi; break; }
    }
    if (footerIdx < 0) {
      return { success: false, protocolName: "JBF293K", summary: "",
               fields: [], error: "缺少结束符 0x83" };
    }

    // 数据区 + 校验区 (结束符之前)
    var rawDataPortion = dataBytes.slice(0, footerIdx);

    // 解码所有数据字
    var words = [];
    for (var wi = 0; wi + 1 < rawDataPortion.length; wi += 2) {
      words.push(decodeWord(rawDataPortion[wi], rawDataPortion[wi + 1]));
    }

    if (words.length < 1) {
      return { success: false, protocolName: "JBF293K", summary: "",
               fields: [], error: "数据字不足" };
    }

    // D1 = 命令字/类型码
    var orderType = words[0];
    fields.push({ key: "rawOrder", label: "原始命令码", value: "0x" + padHex(orderType, 2), group: "帧头", uiType: "code" });

    // 判断命令类型
    var alarmDef = ALARM_MAP[orderType];
    var isSpray = (orderType === 0xFA || orderType === 0x70 || orderType === 0x71 || orderType === 0x72);
    var isFireDoor = (orderType === 0xFB);
    var isEleFire = (orderType === 0xFC);

    var orderName = "";
    var orderColor = "slate";
    var parserType = "";

    if (alarmDef) {
      orderName = alarmDef.name;
      parserType = alarmDef.parser;
      orderColor = (orderType === 0x80 || orderType === 0x0A) ? "red" :
                   (orderType === 0x81 || orderType === 0x87 || orderType === 0xEF) ? "amber" :
                   (orderType === 0x82 || orderType === 0x88 || orderType === 0x09) ? "emerald" :
                   "blue";
    } else if (isSpray) {
      orderName = orderType === 0xFA ? "气体喷洒系统" : orderType === 0x70 ? "板故障" : orderType === 0x71 ? "主电" : "备电";
      parserType = "spray";
      orderColor = "purple";
    } else if (isFireDoor) {
      orderName = "防火门";
      parserType = "firedoor";
      orderColor = "blue";
    } else if (isEleFire) {
      orderName = "电气火灾";
      parserType = "elefire";
      orderColor = "amber";
    } else {
      orderName = "未知命令(0x" + padHex(orderType, 2) + ")";
    }

    fields.push({
      key: "order", label: "命令类型",
      value: orderName,
      group: "帧头", uiType: "badge", color: orderColor, isKeyInfo: true
    });

    // 判断是否为扩展模式(电气火灾 D5=0xFF)
    var isExtended = false;
    var extWords = [];
    if (isEleFire && words.length >= 5 && words[4] === 0xFF) {
      isExtended = true;
    }

    // 标准数据区(D2-D5)
    if (parserType === "heart") parseHeartData(words, fields);
    else if (parserType === "version") parseVersionData(words, fields);
    else if (parserType === "common") parseCommonData(words, fields);
    else if (parserType === "multiline") parseMultilineData(words, fields);
    else if (parserType === "simulation") parseSimulationData(words, fields);
    else if (parserType === "spray") parseSprayData(orderType, words, fields);
    else if (parserType === "firedoor") parseFireDoorData(words, fields);
    else if (parserType === "elefire") {
      // 需要先判断是否有扩展数据
      if (isExtended && words.length >= 16) {
        // 扩展模式: D6-D11=时间, D12=累加和已验, D13-D16=扩展
        extWords = words.slice(12, 16);
      }
      parseEleFireData(words, isExtended, extWords, fields);
    }

    // 时间(D6-D11): 从words[5]开始
    var hasTime = true;
    if (parserType === "version") {
      hasTime = false; // 版本命令没有时间字段
    }
    if (hasTime && words.length >= 11) {
      var timeStr = parseTime(words, 5);
      fields.push({ key: "time", label: "时间", value: timeStr, group: "数据区" });
    }

    // 校验和
    // 计算累加和: 从D1到D11(words[0]-words[10])的累加
    var checkWordCount = Math.min(words.length - 1, 11); // 最后一个word是校验值
    var calcSum = 0;
    for (var si = 0; si < checkWordCount; si++) {
      calcSum = (calcSum + words[si]) & 0xFF;
    }
    var recvSum = words.length > 11 ? words[11] : -1;

    if (recvSum >= 0) {
      var sumOk = (calcSum === recvSum);
      var sumDisplay = "0x" + padHex(recvSum, 2);
      if (sumOk) {
        sumDisplay += " \u2713 校验通过";
      } else {
        sumDisplay += " \u2717 校验失败 (预期 0x" + padHex(calcSum, 2) + ")";
      }
      fields.push({
        key: "checksum", label: "累加和校验",
        value: sumDisplay,
        group: "校验区", uiType: "status-dot", color: sumOk ? "emerald" : "red", isKeyInfo: true
      });
    }

    // 扩展数据CRC8校验(电气火灾扩展模式)
    if (isExtended && words.length >= 16) {
      // CRC8-MAXIM 覆盖所有数据字
      var crcData = [];
      for (var ci = 0; ci <= Math.min(words.length - 2, 15); ci++) {
        crcData.push(words[ci] & 0xFF);
      }
      var calcCrc = crc8Maxim(crcData);
      var recvCrc = words.length > 16 ? words[16] : -1;
      if (recvCrc >= 0) {
        var crcOk = (calcCrc === recvCrc);
        var crcDisplay = "0x" + padHex(recvCrc, 2);
        crcDisplay += crcOk ? " \u2713 校验通过" : " \u2717 校验失败 (预期 0x" + padHex(calcCrc, 2) + ")";
        fields.push({
          key: "crc8", label: "CRC8-MAXIM 校验",
          value: crcDisplay,
          group: "校验区", uiType: "status-dot", color: crcOk ? "emerald" : "red"
        });
      }
    }

    // 结束符
    fields.push({ key: "footer", label: "结束符", value: "0x83", group: "帧尾", uiType: "code" });

    // 报文总长
    fields.push({ key: "totalLen", label: "报文总长度", value: bytes.length + " 字节", group: "帧尾" });

    // 原始数据
    fields.push({ key: "rawHex", label: "原始十六进制", value: hex, group: "帧尾", uiType: "code" });

    // 摘要
    var summary = "JBF293K " + orderName;
    if (words.length > 1 && parserType !== "heart" && parserType !== "version") {
      summary += " [机器号:" + words[1] + "]";
    }

    var layout = buildLayout(fields);

    return {
      success: true,
      protocolName: "JBF293K",
      summary: summary,
      fields: fields,
      layout: layout
    };

  } catch (e) {
    return {
      success: false,
      protocolName: "JBF293K",
      summary: "",
      fields: [],
      error: "解析异常: " + e.toString()
    };
  }
}

// ═══════════════════════════════════════════
//  Layout 布局生成
// ═══════════════════════════════════════════

function buildLayout(fields) {
  var sections = [];
  var groupMap = {};
  var groupOrder = [];
  for (var i = 0; i < fields.length; i++) {
    var f = fields[i];
    var g = f.group || "__ungrouped";
    if (!groupMap[g]) { groupMap[g] = []; groupOrder.push(g); }
    groupMap[g].push(f);
  }

  var styleMap = {
    "帧头": { style: "key-value", color: "blue" },
    "数据区": { style: "key-value", color: "teal" },
    "扩展数据": { style: "key-value", color: "purple" },
    "校验区": { style: "key-value", color: "amber" },
    "帧尾": { style: "key-value", color: "slate" }
  };

  for (var gi = 0; gi < groupOrder.length; gi++) {
    var group = groupOrder[gi];
    var gFields = groupMap[group];
    var mapping = styleMap[group] || { style: "key-value", color: "slate" };
    var keys = [];
    for (var ki = 0; ki < gFields.length; ki++) keys.push(gFields[ki].key);
    sections.push({ title: group, style: mapping.style, color: mapping.color, fieldKeys: keys });
  }

  return { sections: sections };
}

// ═══════════════════════════════════════════
//  报文生成器
// ═══════════════════════════════════════════

function generate(params) {
  try {
    var orderType = parseInt(params.orderType || "0", 16);
    var machineNo = parseInt(params.machineNo || "1");
    var circuit = parseInt(params.circuit || "1");
    var address = parseInt(params.address || "1");
    var d5 = parseInt(params.d5 || "0");

    // 编码一个字节为2字节ASCII
    function encodeWord(val) {
      var hi = ((val >> 4) & 0x0F) + 0x30;
      var lo = (val & 0x0F) + 0x30;
      return [hi, lo];
    }

    var packet = [];
    // 起始符
    packet.push(0x82);

    // D1-D5
    var dataWords = [orderType, machineNo, circuit, address, d5];
    var summation = 0;
    for (var i = 0; i < dataWords.length; i++) {
      var encoded = encodeWord(dataWords[i] & 0xFF);
      packet.push(encoded[0], encoded[1]);
      summation = (summation + (dataWords[i] & 0xFF)) & 0xFF;
    }

    // D6-D11: 当前时间
    var now = new Date();
    var timeWords = [
      now.getFullYear() - 2000, now.getMonth() + 1, now.getDate(),
      now.getHours(), now.getMinutes(), now.getSeconds()
    ];
    for (var t = 0; t < timeWords.length; t++) {
      var te = encodeWord(timeWords[t] & 0xFF);
      packet.push(te[0], te[1]);
      summation = (summation + (timeWords[t] & 0xFF)) & 0xFF;
    }

    // D12: 累加和
    var sumEncoded = encodeWord(summation);
    packet.push(sumEncoded[0], sumEncoded[1]);

    // 结束符
    packet.push(0x83);

    var message = bytesToHex(packet);

    return {
      success: true,
      protocolName: "JBF293K",
      message: message,
      formatted: message.replace(/(.{2})/g, "$1 ").trim()
    };

  } catch (e) {
    return {
      success: false,
      protocolName: "JBF293K",
      message: "",
      error: "生成异常: " + e.toString()
    };
  }
}
