// icon-pack 类型插件无需 JavaScript 运行时
// 此文件仅作为 entrypoint 占位
