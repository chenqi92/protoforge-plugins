/**
 * mock-data-gen — Mock 数据生成器
 *
 * 支持的 generatorId:
 *   - uuid:          UUID v4
 *   - random-string: 随机字母数字字符串 (options.length, default 16)
 *   - random-int:    随机整数 (options.min, options.max, default 0-100)
 *   - timestamp:     当前 Unix 时间戳 (options.unit: "s"|"ms", default "ms")
 *   - random-email:  随机邮箱地址
 *   - random-ip:     随机 IPv4 地址
 *
 * generate(generatorId, options) → { data: "..." }
 */

function generate(generatorId, options) {
  var opts = options || {};

  switch (generatorId) {
    case "uuid":
      return { data: generateUUID() };

    case "random-string":
      var len = opts.length || 16;
      return { data: randomString(len) };

    case "random-int":
      var min = opts.min !== undefined ? opts.min : 0;
      var max = opts.max !== undefined ? opts.max : 100;
      var val = Math.floor(Math.random() * (max - min + 1)) + min;
      return { data: val.toString() };

    case "timestamp":
      var unit = opts.unit || "ms";
      var ts = unit === "s" ? Math.floor(Date.now() / 1000) : Date.now();
      return { data: ts.toString() };

    case "random-email":
      return { data: randomEmail() };

    case "random-ip":
      return { data: randomIPv4() };

    default:
      return { data: "", error: "Unknown generatorId: " + generatorId };
  }
}

// UUID v4 generator (RFC 4122 compliant)
function generateUUID() {
  var hex = "0123456789abcdef";
  var uuid = "";
  for (var i = 0; i < 36; i++) {
    if (i === 8 || i === 13 || i === 18 || i === 23) {
      uuid += "-";
    } else if (i === 14) {
      uuid += "4";  // version 4
    } else if (i === 19) {
      uuid += hex.charAt((Math.floor(Math.random() * 4)) + 8);  // variant 10xx
    } else {
      uuid += hex.charAt(Math.floor(Math.random() * 16));
    }
  }
  return uuid;
}

function randomString(len) {
  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  var result = "";
  for (var i = 0; i < len; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

function randomEmail() {
  var names = ["user", "test", "dev", "admin", "hello", "demo", "mock", "sample"];
  var domains = ["example.com", "test.org", "mock.dev", "demo.io", "sample.net"];
  var name = names[Math.floor(Math.random() * names.length)];
  var suffix = Math.floor(Math.random() * 9999);
  var domain = domains[Math.floor(Math.random() * domains.length)];
  return name + suffix + "@" + domain;
}

function randomIPv4() {
  var a = Math.floor(Math.random() * 223) + 1;
  var b = Math.floor(Math.random() * 256);
  var c = Math.floor(Math.random() * 256);
  var d = Math.floor(Math.random() * 254) + 1;
  return a + "." + b + "." + c + "." + d;
}
