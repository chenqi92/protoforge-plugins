/**
 * mock-data-gen v2.0.0 — Mock 数据生成器
 *
 * generate(generatorId, options) → { data: "..." }
 */

function generate(generatorId, options) {
  var opts = options || {};
  switch (generatorId) {
    case "uuid": return { data: generateUUID() };
    case "uuid-no-dash": return { data: generateUUID().replace(/-/g, "") };
    case "uuid-short": return { data: shortUUID() };
    case "random-string": return { data: randomString(opts.length || 16) };
    case "random-int": {
      var min = opts.min !== undefined ? opts.min : 0;
      var max = opts.max !== undefined ? opts.max : 100;
      return { data: (Math.floor(Math.random() * (max - min + 1)) + min).toString() };
    }
    case "timestamp": {
      var unit = opts.unit || "ms";
      var ts = unit === "s" ? Math.floor(Date.now() / 1000) : Date.now();
      return { data: ts.toString() };
    }
    case "datetime-iso": return { data: new Date().toISOString() };
    case "datetime-cn": return { data: formatDateCN(new Date()) };
    case "datetime-date": return { data: formatDateOnly(new Date()) };
    case "datetime-time": return { data: formatTimeOnly(new Date()) };
    case "random-name-cn": return { data: randomChineseName() };
    case "random-phone-cn": return { data: randomPhoneCN() };
    case "random-idcard": return { data: randomIDCard() };
    case "random-email": return { data: randomEmail() };
    case "random-ip": return { data: randomIPv4() };
    case "random-ipv6": return { data: randomIPv6() };
    case "random-url": return { data: randomURL() };
    case "random-color": return { data: randomColor() };
    case "random-mac": return { data: randomMAC() };
    default: return { data: "", error: "Unknown generatorId: " + generatorId };
  }
}

// ── UUID v4 (RFC 4122) ──

function generateUUID() {
  var hex = "0123456789abcdef";
  var uuid = "";
  for (var i = 0; i < 36; i++) {
    if (i === 8 || i === 13 || i === 18 || i === 23) uuid += "-";
    else if (i === 14) uuid += "4";
    else if (i === 19) uuid += hex.charAt((Math.floor(Math.random() * 4)) + 8);
    else uuid += hex.charAt(Math.floor(Math.random() * 16));
  }
  return uuid;
}

function shortUUID() {
  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  var ts = Date.now().toString(36);
  var rand = "";
  for (var i = 0; i < 4; i++) rand += chars.charAt(Math.floor(Math.random() * chars.length));
  return (ts + rand).slice(-8);
}

// ── 字符串/整数 ──

function randomString(len) {
  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  var result = "";
  for (var i = 0; i < len; i++) result += chars.charAt(Math.floor(Math.random() * chars.length));
  return result;
}

// ── 日期时间 ──

function pad2(n) { return n < 10 ? "0" + n : "" + n; }

function formatDateCN(d) {
  return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()) +
    " " + pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds());
}

function formatDateOnly(d) {
  return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate());
}

function formatTimeOnly(d) {
  return pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds());
}

// ── 随机中文姓名 ──

function randomChineseName() {
  var surnames = [
    "\u8d75","\u94b1","\u5b59","\u674e","\u5468","\u5434","\u90d1","\u738b",
    "\u51af","\u9648","\u696e","\u536b","\u848b","\u6c88","\u97e9","\u6768",
    "\u6731","\u79e6","\u5c24","\u8bb8","\u4f55","\u5415","\u65bd","\u5f20",
    "\u5b54","\u66f9","\u4e25","\u534e","\u91d1","\u9b4f","\u9676","\u59dc",
    "\u6234","\u8c22","\u90b9","\u67cf","\u6c34","\u7aa6","\u7ae0","\u4e91",
    "\u82cf","\u6f58","\u845b","\u595a","\u8303","\u5f6d","\u90ce","\u9c81",
    "\u9f9a","\u5eb7","\u4e07","\u4fde","\u9ec4","\u5510","\u8d3a","\u9a6c",
    "\u9f54","\u90b5","\u6e5b","\u6c6a","\u7941","\u6bdb","\u79b9","\u72c4",
    "\u7c73","\u660e","\u81e7","\u8ba1","\u4f0f","\u6210","\u590f","\u5b97",
    "\u4e01","\u8d3e","\u5362","\u5d14","\u7a0b","\u5415","\u4f59","\u5362"
  ];
  var names = [
    "\u4f1f","\u82b3","\u5a1c","\u79c0\u82f1","\u654f","\u9759","\u4e3d",
    "\u5f3a","\u78ca","\u519b","\u6d0b","\u52c7","\u8273","\u6770","\u5a1f",
    "\u6dbc","\u6d69","\u5b87","\u6b23","\u6b23\u7136","\u5b50\u6db5",
    "\u96e8\u6cfd","\u6d69\u5b87","\u6893\u840d","\u6893\u6676","\u5b50\u8f69",
    "\u6d69\u7136","\u96e8\u8431","\u6613\u535a","\u7389\u5170","\u5efa\u56fd",
    "\u5efa\u534e","\u6d77\u71d5","\u5fd7\u660e","\u5fd7\u5f3a","\u4e16\u6770",
    "\u7acb\u8f89","\u6587\u660e","\u5a05","\u5a77\u5a77","\u601d\u6dbc",
    "\u5609\u7199","\u6653\u6668","\u7fce\u5b89","\u5b50\u9e4f","\u6d69\u8f69",
    "\u6021\u541b","\u5a49\u513f","\u96e8\u5a63","\u96ea\u6885","\u767d\u4e91"
  ];
  return surnames[Math.floor(Math.random() * surnames.length)] +
         names[Math.floor(Math.random() * names.length)];
}

// ── 随机手机号 (中国运营商号段) ──

function randomPhoneCN() {
  // 中国三大运营商常见号段前缀
  var prefixes = [
    "130","131","132","133","134","135","136","137","138","139",
    "145","147","148","149",
    "150","151","152","153","155","156","157","158","159",
    "162","165","166","167",
    "170","171","172","173","175","176","177","178",
    "180","181","182","183","184","185","186","187","188","189",
    "190","191","192","193","195","196","197","198","199"
  ];
  var prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  var suffix = "";
  for (var i = 0; i < 8; i++) suffix += Math.floor(Math.random() * 10).toString();
  return prefix + suffix;
}

// ── 随机身份证号 (18位, 含校验码) ──

function randomIDCard() {
  // 常见地区码 (简化版)
  var areaCodes = [
    "110101","110102","110105","110108","110109",
    "310101","310104","310105","310106","310107",
    "440103","440104","440105","440106","440111",
    "320102","320104","320105","320106","320111",
    "330102","330103","330104","330105","330106",
    "420102","420103","420104","420105","420106",
    "510104","510105","510106","510107","510108",
    "500101","500102","500103","500104","500105",
    "370102","370103","370104","370105","370112",
    "350102","350103","350104","350105","350111"
  ];
  var area = areaCodes[Math.floor(Math.random() * areaCodes.length)];

  // 生成随机出生日期 (1960-2005)
  var year = 1960 + Math.floor(Math.random() * 45);
  var month = 1 + Math.floor(Math.random() * 12);
  var maxDay = [31,28,31,30,31,30,31,31,30,31,30,31][month - 1];
  if (month === 2 && ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0)) maxDay = 29;
  var day = 1 + Math.floor(Math.random() * maxDay);
  var birth = year.toString() + pad2(month) + pad2(day);

  // 顺序码 (3位, 奇数=男, 偶数=女)
  var seq = (Math.floor(Math.random() * 999) + 1).toString();
  while (seq.length < 3) seq = "0" + seq;

  var id17 = area + birth + seq;

  // 校验码计算 (ISO 7064:1983, MOD 11-2)
  var weights = [7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2];
  var checkChars = "10X98765432";
  var sum = 0;
  for (var i = 0; i < 17; i++) sum += parseInt(id17.charAt(i)) * weights[i];
  var checkCode = checkChars.charAt(sum % 11);

  return id17 + checkCode;
}

// ── Email ──

function randomEmail() {
  var names = ["user","test","dev","admin","hello","demo","mock","sample","zhangsan","lisi","wangwu"];
  var domains = ["example.com","test.org","mock.dev","demo.io","sample.net","gmail.com","outlook.com","163.com","qq.com"];
  return names[Math.floor(Math.random() * names.length)] +
    Math.floor(Math.random() * 9999) + "@" +
    domains[Math.floor(Math.random() * domains.length)];
}

// ── IP ──

function randomIPv4() {
  var a = Math.floor(Math.random() * 223) + 1;
  var b = Math.floor(Math.random() * 256);
  var c = Math.floor(Math.random() * 256);
  var d = Math.floor(Math.random() * 254) + 1;
  return a + "." + b + "." + c + "." + d;
}

function randomIPv6() {
  var hex = "0123456789abcdef";
  var parts = [];
  for (var i = 0; i < 8; i++) {
    var seg = "";
    for (var j = 0; j < 4; j++) seg += hex.charAt(Math.floor(Math.random() * 16));
    parts.push(seg);
  }
  return parts.join(":");
}

// ── URL ──

function randomURL() {
  var domains = ["api.example.com","service.mock.dev","demo.test.io","app.sample.net","gateway.dev.com"];
  var paths = ["users","orders","products","items","data","search","api/v1","api/v2","health","config"];
  var domain = domains[Math.floor(Math.random() * domains.length)];
  var path = paths[Math.floor(Math.random() * paths.length)];
  var id = Math.floor(Math.random() * 99999);
  return "https://" + domain + "/" + path + "/" + id;
}

// ── 颜色 ──

function randomColor() {
  var hex = "0123456789ABCDEF";
  var color = "#";
  for (var i = 0; i < 6; i++) color += hex.charAt(Math.floor(Math.random() * 16));
  return color;
}

// ── MAC 地址 ──

function randomMAC() {
  var hex = "0123456789ABCDEF";
  var parts = [];
  for (var i = 0; i < 6; i++) {
    parts.push(hex.charAt(Math.floor(Math.random() * 16)) + hex.charAt(Math.floor(Math.random() * 16)));
  }
  return parts.join(":");
}
