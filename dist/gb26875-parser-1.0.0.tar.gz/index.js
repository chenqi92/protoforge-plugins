/**
 * GB 26875.3-2011 城市消防远程监控系统 — 报警传输网络通信协议完整解析器 + 报文生成器
 *
 * 完全支持《城市消防远程监控系统 第3部分：报警传输网络通信协议》(GB 26875.3-2011)
 * 适用于建筑消防设施与用户信息传输装置的数据上报与查询
 *
 * 帧格式 (十六进制):
 *   @@(2B) [流水号2B] [主版本1B] [用户版本1B] [时间戳6B]
 *   [源地址6B] [目的地址6B] [数据长度2B] [命令字1B]
 *   [应用数据N B] [校验和1B] ##(2B)
 */

// ═══════════════════════════════════════════
//  工具函数
// ═══════════════════════════════════════════

function hexToBytes(hex) {
  hex = hex.replace(/\s+/g, "");
  var bytes = [];
  for (var i = 0; i < hex.length; i += 2) {
    bytes.push(parseInt(hex.substring(i, i + 2), 16));
  }
  return bytes;
}

function bytesToHex(bytes) {
  var r = "";
  for (var i = 0; i < bytes.length; i++) {
    var h = bytes[i].toString(16).toUpperCase();
    if (h.length < 2) h = "0" + h;
    r += h;
  }
  return r;
}

function readUint16LE(bytes, offset) {
  return (bytes[offset] & 0xFF) | ((bytes[offset + 1] & 0xFF) << 8);
}

function writeUint16LE(val) {
  return [val & 0xFF, (val >> 8) & 0xFF];
}

function padHex(val, len) {
  var s = val.toString(16).toUpperCase();
  while (s.length < len) s = "0" + s;
  return s;
}

function formatMac(bytes, offset) {
  var parts = [];
  for (var i = 0; i < 6; i++) {
    parts.push(padHex(bytes[offset + i], 2));
  }
  return parts.join(":");
}

// 时间解析: 6字节，线序为 秒/分/时/日/月/年(偏移2000)
function readTime(bytes, offset) {
  var sec = bytes[offset] & 0xFF;
  var min = bytes[offset + 1] & 0xFF;
  var hour = bytes[offset + 2] & 0xFF;
  var day = bytes[offset + 3] & 0xFF;
  var month = bytes[offset + 4] & 0xFF;
  var year = (bytes[offset + 5] & 0xFF) + 2000;
  return year + "-" + pad2(month) + "-" + pad2(day) + " " +
         pad2(hour) + ":" + pad2(min) + ":" + pad2(sec);
}

function pad2(n) {
  return n < 10 ? "0" + n : "" + n;
}

// 校验和: 从第3字节(index=2)到校验和字节之前的算术和，取低8位
function computeChecksum(bytes, start, end) {
  var sum = 0;
  for (var i = start; i < end; i++) {
    sum = (sum + (bytes[i] & 0xFF)) & 0xFF;
  }
  return sum;
}

// ═══════════════════════════════════════════
//  控制命令字
// ═══════════════════════════════════════════

var CONTROL_ORDERS = {
  0: "保留",
  1: "控制命令",
  2: "发送数据",
  3: "确认",
  4: "请求",
  5: "应答",
  6: "否认"
};

function getControlOrder(code) {
  if (CONTROL_ORDERS[code] !== undefined) return CONTROL_ORDERS[code];
  if (code >= 7 && code <= 127) return "保留(" + code + ")";
  return "用户自定义(" + code + ")";
}

// ═══════════════════════════════════════════
//  数据类型标识
// ═══════════════════════════════════════════

var TYPE_NAMES = {
  0: "保留",
  1: "上传建筑消防设施系统状态",
  2: "上传建筑消防设施部件运行状态",
  3: "上传建筑消防设施部件模拟量值",
  4: "上传建筑消防设施操作信息",
  5: "上传建筑消防设施软件版本",
  6: "上传建筑消防设施系统配置",
  7: "上传建筑消防设施部件配置",
  8: "上传建筑消防设施系统时间",
  21: "上传用户信息传输装置运行状态",
  24: "上传用户信息传输装置操作信息",
  25: "上传用户信息传输装置软件版本",
  26: "上传用户信息传输装置配置",
  28: "上传用户信息传输装置系统时间",
  61: "读建筑消防设施系统状态",
  62: "读建筑消防设施部件运行状态",
  63: "读建筑消防设施部件模拟量值",
  64: "读建筑消防设施操作信息",
  65: "读建筑消防设施软件版本",
  66: "读建筑消防设施系统配置",
  67: "读建筑消防设施部件配置",
  68: "读建筑消防设施系统时间",
  81: "读用户信息传输装置运行状态",
  84: "读用户信息传输装置操作信息记录",
  85: "读用户信息传输装置软件版本",
  86: "读用户信息传输装置配置",
  88: "读用户信息传输装置系统时间",
  89: "初始化用户信息传输装置",
  90: "同步用户信息传输装置时钟",
  91: "查岗命令"
};

// ═══════════════════════════════════════════
//  系统类型 (Type1STEnum)
// ═══════════════════════════════════════════

var SYSTEM_TYPES = {
  0: "通用",
  1: "火灾报警系统",
  10: "消防联动控制器",
  11: "消火栓系统",
  12: "自动喷水灭火系统",
  13: "气体灭火系统",
  14: "水喷雾灭火系统(泵启动)",
  15: "水喷雾灭火系统(压力容器启动)",
  16: "泡沫灭火系统",
  17: "干粉灭火系统",
  18: "防烟排烟系统",
  19: "防火门及卷帘系统",
  20: "消防电梯",
  21: "消防应急广播",
  22: "消防应急照明和疏散指示系统",
  23: "消防电源",
  24: "消防电话"
};

// ═══════════════════════════════════════════
//  部件类型 (Type2STEnum) — 122种
// ═══════════════════════════════════════════

var COMPONENT_TYPES = {
  0: "通用", 1: "火灾报警控制器",
  10: "可燃气体探测器", 11: "点型可燃气体探测器", 12: "独立式可燃气体探测器", 13: "线型可燃气体探测器",
  16: "电气火灾监控报警器", 17: "剩余电流式电气火灾监控探测器", 18: "测温式电气火灾监控探测器",
  21: "探测回路", 22: "火灾显示盘", 23: "手动火灾报警按钮", 24: "消火栓按钮", 25: "火灾探测器",
  30: "感温火灾探测器", 31: "点型感温火灾探测器", 32: "点型感温火灾探测器(S型)", 33: "点型感温火灾探测器(R型)",
  34: "线型感温火灾探测器", 35: "线型感温火灾探测器(S型)", 36: "线型感温火灾探测器(R型)", 37: "光纤感温火灾探测器",
  40: "感烟火灾探测器", 41: "点型离子感烟火灾探测器", 42: "点型光电感烟火灾探测器",
  43: "线型光束感烟火灾探测器", 44: "吸气式感烟火灾探测器",
  50: "复合式火灾探测器", 51: "复合式感烟感温火灾探测器", 52: "复合式感光感温火灾探测器", 53: "复合式感光感烟火灾探测器",
  61: "紫外火焰探测器", 62: "红外火焰探测器",
  69: "感光火灾探测器", 74: "气体探测器", 78: "图像/摄像火灾探测器", 79: "感声火灾探测器",
  81: "气体灭火控制器", 82: "消防电气控制装置", 83: "消防控制室图形显示装置",
  84: "模块", 85: "输入模块", 86: "输出模块", 87: "输入/输出模块", 88: "中继模块",
  91: "消防水泵", 92: "消防水箱", 95: "喷淋泵",
  96: "水流指示器", 97: "信号阀", 98: "报警阀", 99: "压力开关",
  101: "阀驱动装置", 102: "防火门", 103: "防火阀", 104: "通风空调",
  105: "泡沫液泵", 106: "管网电磁阀",
  111: "排烟风机", 113: "排烟防火阀", 114: "常闭送风口", 115: "排烟口",
  116: "电控挡烟垂壁", 117: "防火卷帘控制器", 118: "防火门监控器",
  121: "警报装置"
};

// ═══════════════════════════════════════════
//  状态位图定义
// ═══════════════════════════════════════════

// Type1SSEnum — 系统状态(16位)
var SYS_STATUS_BITS = [
  ["测试状态", "正常监视状态"],
  ["无火警", "火警"],
  ["无故障", "故障"],
  ["无屏蔽", "屏蔽"],
  ["无监管", "监管"],
  ["停止(关闭)", "启动(开启)"],
  ["无反馈", "反馈"],
  ["未延时", "延时状态"],
  ["主电正常", "主电故障"],
  ["备电正常", "备电故障"],
  ["总线正常", "总线故障"],
  ["自动状态", "手动状态"],
  ["无配置改变", "配置改变"],
  ["正常", "复位"],
  ["", ""],
  ["", ""]
];

// Type2SSEnum — 部件状态(16位)
var COMP_STATUS_BITS = [
  ["测试状态", "正常监视状态"],
  ["无火警", "火警"],
  ["无故障", "故障"],
  ["无屏蔽", "屏蔽"],
  ["无监管", "监管"],
  ["停止(关闭)", "启动(开启)"],
  ["无反馈", "反馈"],
  ["未延时", "延时状态"],
  ["电源正常", "电源故障"],
  ["", ""], ["", ""], ["", ""], ["", ""], ["", ""], ["", ""], ["", ""]
];

// Type21SSEnum — 传输装置运行状态(8位)
var TRANS_STATUS_BITS = [
  ["测试状态", "正常监视状态"],
  ["无火警", "火警"],
  ["无故障", "故障"],
  ["主电正常", "主电故障"],
  ["备电正常", "备电故障"],
  ["通信信道正常", "与监控中心通信信道故障"],
  ["监测连接线路正常", "监测连接线路故障"],
  ["", ""]
];

// Type4SSEnum — 操作信息(8位)
var OPERATE_BITS = [
  ["", "复位"],
  ["", "消音"],
  ["", "手动报警"],
  ["", "警情消除"],
  ["", "自检"],
  ["", "确认"],
  ["", "测试"],
  ["", ""]
];

// Type24SSEnum — 传输装置操作信息(8位)
var TRANS_OPERATE_BITS = [
  ["", "复位"],
  ["", "消音"],
  ["", "手动报警"],
  ["", "警情消除"],
  ["", "自检"],
  ["", "查岗应答"],
  ["", "测试"],
  ["", ""]
];

// ═══════════════════════════════════════════
//  模拟量类型 (Type3AQEnum)
// ═══════════════════════════════════════════

var ANALOG_TYPES = {
  0: { name: "未使用", unit: "" },
  1: { name: "事件计数", unit: "件" },
  2: { name: "高度", unit: "m" },
  3: { name: "温度", unit: "℃" },
  4: { name: "压力(MPa)", unit: "MPa" },
  5: { name: "压力(kPa)", unit: "kPa" },
  6: { name: "气体浓度", unit: "%LEL" },
  7: { name: "时间", unit: "s" },
  8: { name: "电压", unit: "V" },
  9: { name: "电流", unit: "A" },
  10: { name: "流量", unit: "L/s" },
  11: { name: "风量", unit: "m\u00B3/min" },
  12: { name: "风速", unit: "m/s" }
};

// ═══════════════════════════════════════════
//  位图解析
// ═══════════════════════════════════════════

function parseBitMap(bytes, bitDefs) {
  var results = [];
  var totalBits = bitDefs.length;
  for (var bit = 0; bit < totalBits; bit++) {
    var byteIndex = Math.floor(bit / 8);
    var bitIndex = bit % 8;
    if (byteIndex >= bytes.length) break;
    var isSet = ((bytes[byteIndex] & (1 << bitIndex)) !== 0) ? 1 : 0;
    var desc = bitDefs[bit][isSet];
    if (desc && desc.length > 0) {
      results.push({ bit: bit, set: isSet, desc: desc });
    }
  }
  return results;
}

function bitMapToString(bytes, bitDefs) {
  var items = parseBitMap(bytes, bitDefs);
  var parts = [];
  for (var i = 0; i < items.length; i++) {
    parts.push(items[i].desc);
  }
  return parts.join(", ");
}

function bitsToBinaryStr(bytes) {
  var s = "";
  for (var i = bytes.length - 1; i >= 0; i--) {
    for (var b = 7; b >= 0; b--) {
      s += ((bytes[i] >> b) & 1) ? "1" : "0";
    }
  }
  return s;
}

// ═══════════════════════════════════════════
//  应用数据解析(按类型分发)
// ═══════════════════════════════════════════

function parseAppData(bytes, offset, dataLen, fields) {
  if (dataLen < 2) return;
  var typeFlag = bytes[offset] & 0xFF;
  var infoCount = bytes[offset + 1] & 0xFF;

  var typeName = TYPE_NAMES[typeFlag] || "未知类型(" + typeFlag + ")";
  var isAlarm = (typeFlag >= 1 && typeFlag <= 4) || typeFlag === 21 || typeFlag === 24;
  var typeColor = isAlarm ? "red" : typeFlag >= 61 ? "blue" : "purple";

  fields.push({
    key: "dataType", label: "数据类型标识",
    value: typeFlag + " (" + typeName + ")",
    group: "应用数据", uiType: "badge", color: typeColor, isKeyInfo: true
  });
  fields.push({
    key: "infoCount", label: "信息对象数",
    value: "" + infoCount,
    group: "应用数据"
  });

  var dataStart = offset + 2;
  var dataEnd = offset + dataLen;
  var objLen = (infoCount > 0) ? Math.floor((dataEnd - dataStart) / infoCount) : 0;

  for (var i = 0; i < infoCount; i++) {
    var objOffset = dataStart + i * objLen;
    if (objOffset >= dataEnd) break;
    var groupName = infoCount > 1 ? "信息对象 #" + (i + 1) : "信息对象";
    parseInfoObject(bytes, objOffset, objLen, typeFlag, fields, groupName, i);
  }
}

function parseInfoObject(bytes, offset, objLen, typeFlag, fields, groupName, idx) {
  var pos = offset;
  var end = offset + objLen;
  var prefix = idx > 0 ? "obj" + idx + "_" : "";

  switch (typeFlag) {
    case 1: parseType1(bytes, pos, end, fields, groupName, prefix); break;
    case 2: parseType2(bytes, pos, end, fields, groupName, prefix); break;
    case 3: parseType3(bytes, pos, end, fields, groupName, prefix); break;
    case 4: parseType4(bytes, pos, end, fields, groupName, prefix); break;
    case 5: parseType5(bytes, pos, end, fields, groupName, prefix); break;
    case 6: parseType6(bytes, pos, end, fields, groupName, prefix); break;
    case 7: parseType7(bytes, pos, end, fields, groupName, prefix); break;
    case 8: parseType8(bytes, pos, end, fields, groupName, prefix); break;
    case 21: parseType21(bytes, pos, end, fields, groupName, prefix); break;
    case 24: parseType24(bytes, pos, end, fields, groupName, prefix); break;
    case 25: parseType25(bytes, pos, end, fields, groupName, prefix); break;
    case 26: parseType26(bytes, pos, end, fields, groupName, prefix); break;
    case 28: parseType28(bytes, pos, end, fields, groupName, prefix); break;
    default:
      if (pos < end) {
        fields.push({
          key: prefix + "rawData", label: "原始数据",
          value: bytesToHex(bytes.slice(pos, end)),
          group: groupName, uiType: "code"
        });
      }
  }
}

// Type1: 系统状态 [系统类型1B][系统地址1B][系统状态2B][时间6B] = 10B
function parseType1(bytes, pos, end, fields, group, prefix) {
  if (pos + 10 > end) return;
  var sysType = bytes[pos] & 0xFF;
  fields.push({ key: prefix + "sysType", label: "系统类型", value: sysType + " (" + (SYSTEM_TYPES[sysType] || "未知") + ")", group: group, uiType: "badge", color: "blue" });
  pos++;
  fields.push({ key: prefix + "sysAddr", label: "系统地址", value: "" + (bytes[pos] & 0xFF), group: group });
  pos++;
  // 状态2字节(小端翻转)
  var statusBytes = [bytes[pos + 1], bytes[pos]]; // 翻转字节序
  var statusStr = bitMapToString(statusBytes, SYS_STATUS_BITS);
  var binStr = bitsToBinaryStr(statusBytes);
  fields.push({ key: prefix + "sysStatus", label: "系统状态", value: statusStr, group: group, tooltip: "二进制: " + binStr });
  // 位图字段
  var alarmItems = parseBitMap(statusBytes, SYS_STATUS_BITS);
  for (var b = 0; b < alarmItems.length; b++) {
    var item = alarmItems[b];
    var bitColor = item.set === 1 ? (item.bit === 0 || item.bit === 5 || item.bit === 6 ? "emerald" : "red") : "emerald";
    if (item.bit === 1 && item.set === 1) bitColor = "red";
    if (item.bit === 2 && item.set === 1) bitColor = "red";
    if (item.bit === 11 && item.set === 1) bitColor = "amber";
    fields.push({ key: prefix + "sysBit" + item.bit, label: "Bit" + item.bit, value: item.desc, group: group, uiType: "status-dot", color: bitColor });
  }
  pos += 2;
  fields.push({ key: prefix + "time", label: "发生时间", value: readTime(bytes, pos), group: group });
}

// Type2: 部件运行状态 [系统类型1B][系统地址1B][部件类型1B][部件地址4B][部件状态2B][部件说明31B][时间6B] = 46B
function parseType2(bytes, pos, end, fields, group, prefix) {
  if (pos + 46 > end) return;
  var sysType = bytes[pos] & 0xFF;
  fields.push({ key: prefix + "sysType", label: "系统类型", value: sysType + " (" + (SYSTEM_TYPES[sysType] || "未知") + ")", group: group, uiType: "badge", color: "blue" });
  pos++;
  fields.push({ key: prefix + "sysAddr", label: "系统地址", value: "" + (bytes[pos] & 0xFF), group: group });
  pos++;
  var partType = bytes[pos] & 0xFF;
  fields.push({ key: prefix + "partType", label: "部件类型", value: partType + " (" + (COMPONENT_TYPES[partType] || "未知") + ")", group: group, uiType: "badge", color: "purple" });
  pos++;
  var partAddr = (bytes[pos] & 0xFF) + "." + (bytes[pos+1] & 0xFF) + "." + (bytes[pos+2] & 0xFF) + "." + (bytes[pos+3] & 0xFF);
  fields.push({ key: prefix + "partAddr", label: "部件地址", value: partAddr, group: group });
  pos += 4;
  // 部件状态2字节(翻转)
  var compStatusBytes = [bytes[pos + 1], bytes[pos]];
  var compStatusStr = bitMapToString(compStatusBytes, COMP_STATUS_BITS);
  fields.push({ key: prefix + "partStatus", label: "部件状态", value: compStatusStr, group: group, tooltip: "二进制: " + bitsToBinaryStr(compStatusBytes) });
  pos += 2;
  // 部件说明31字节 — 尝试解码为文本(忽略尾部0x00)
  var explainBytes = bytes.slice(pos, pos + 31);
  var explain = "";
  for (var i = 0; i < 31; i++) {
    if (explainBytes[i] === 0) break;
    explain += String.fromCharCode(explainBytes[i]);
  }
  if (explain.length > 0) {
    fields.push({ key: prefix + "partExplain", label: "部件说明", value: explain, group: group });
  }
  pos += 31;
  fields.push({ key: prefix + "time", label: "发生时间", value: readTime(bytes, pos), group: group });
}

// Type3: 模拟量值 [系统类型1B][系统地址1B][部件类型1B][部件地址4B][模拟量类型1B][模拟量值2B][时间6B] = 16B
function parseType3(bytes, pos, end, fields, group, prefix) {
  if (pos + 16 > end) return;
  var sysType = bytes[pos] & 0xFF;
  fields.push({ key: prefix + "sysType", label: "系统类型", value: sysType + " (" + (SYSTEM_TYPES[sysType] || "未知") + ")", group: group, uiType: "badge", color: "blue" });
  pos++;
  fields.push({ key: prefix + "sysAddr", label: "系统地址", value: "" + (bytes[pos] & 0xFF), group: group });
  pos++;
  var partType = bytes[pos] & 0xFF;
  fields.push({ key: prefix + "partType", label: "部件类型", value: partType + " (" + (COMPONENT_TYPES[partType] || "未知") + ")", group: group, uiType: "badge", color: "purple" });
  pos++;
  var partAddr = (bytes[pos] & 0xFF) + "." + (bytes[pos+1] & 0xFF) + "." + (bytes[pos+2] & 0xFF) + "." + (bytes[pos+3] & 0xFF);
  fields.push({ key: prefix + "partAddr", label: "部件地址", value: partAddr, group: group });
  pos += 4;
  var aqType = bytes[pos] & 0xFF;
  var aqInfo = ANALOG_TYPES[aqType] || { name: "未知", unit: "" };
  fields.push({ key: prefix + "aqType", label: "模拟量类型", value: aqType + " (" + aqInfo.name + ")", group: group });
  pos++;
  var aqVal = readUint16LE(bytes, pos);
  var aqDisplay = "" + aqVal;
  if (aqInfo.unit) aqDisplay += " " + aqInfo.unit;
  fields.push({ key: prefix + "aqValue", label: "模拟量值", value: aqDisplay, unit: aqInfo.unit, group: group });
  pos += 2;
  fields.push({ key: prefix + "time", label: "发生时间", value: readTime(bytes, pos), group: group });
}

// Type4: 操作信息 [系统类型1B][系统地址1B][操作类型1B][操作员号1B][时间6B] = 10B
function parseType4(bytes, pos, end, fields, group, prefix) {
  if (pos + 10 > end) return;
  var sysType = bytes[pos] & 0xFF;
  fields.push({ key: prefix + "sysType", label: "系统类型", value: sysType + " (" + (SYSTEM_TYPES[sysType] || "未知") + ")", group: group, uiType: "badge", color: "blue" });
  pos++;
  fields.push({ key: prefix + "sysAddr", label: "系统地址", value: "" + (bytes[pos] & 0xFF), group: group });
  pos++;
  var opByte = [bytes[pos]];
  var opItems = parseBitMap(opByte, OPERATE_BITS);
  var opStrs = [];
  for (var i = 0; i < opItems.length; i++) {
    if (opItems[i].set === 1 && opItems[i].desc.length > 0) opStrs.push(opItems[i].desc);
  }
  fields.push({ key: prefix + "operateType", label: "操作类型", value: opStrs.length > 0 ? opStrs.join(", ") : "无操作", group: group, uiType: "badge", color: "amber" });
  pos++;
  fields.push({ key: prefix + "operatorNum", label: "操作员号", value: "" + (bytes[pos] & 0xFF), group: group });
  pos++;
  fields.push({ key: prefix + "time", label: "发生时间", value: readTime(bytes, pos), group: group });
}

// Type5: 软件版本 [系统类型1B][系统地址1B][主版本1B][次版本1B] = 4B
function parseType5(bytes, pos, end, fields, group, prefix) {
  if (pos + 4 > end) return;
  var sysType = bytes[pos] & 0xFF;
  fields.push({ key: prefix + "sysType", label: "系统类型", value: sysType + " (" + (SYSTEM_TYPES[sysType] || "未知") + ")", group: group, uiType: "badge", color: "blue" });
  pos++;
  fields.push({ key: prefix + "sysAddr", label: "系统地址", value: "" + (bytes[pos] & 0xFF), group: group });
  pos++;
  var mainVer = bytes[pos] & 0xFF;
  var minorVer = bytes[pos + 1] & 0xFF;
  fields.push({ key: prefix + "version", label: "软件版本", value: mainVer + "." + minorVer, group: group });
}

// Type6: 系统配置 [系统类型1B][系统地址1B][配置长度1B][配置描述NB]
function parseType6(bytes, pos, end, fields, group, prefix) {
  if (pos + 3 > end) return;
  var sysType = bytes[pos] & 0xFF;
  fields.push({ key: prefix + "sysType", label: "系统类型", value: sysType + " (" + (SYSTEM_TYPES[sysType] || "未知") + ")", group: group, uiType: "badge", color: "blue" });
  pos++;
  fields.push({ key: prefix + "sysAddr", label: "系统地址", value: "" + (bytes[pos] & 0xFF), group: group });
  pos++;
  var confLen = bytes[pos] & 0xFF;
  pos++;
  var confData = bytes.slice(pos, Math.min(pos + confLen, end));
  var confStr = "";
  for (var i = 0; i < confData.length; i++) {
    if (confData[i] === 0) break;
    confStr += String.fromCharCode(confData[i]);
  }
  fields.push({ key: prefix + "sysConf", label: "系统配置", value: confStr || bytesToHex(confData), group: group });
}

// Type7: 部件配置 [系统类型1B][系统地址1B][部件类型1B][部件地址4B][部件说明31B] = 38B
function parseType7(bytes, pos, end, fields, group, prefix) {
  if (pos + 38 > end) return;
  var sysType = bytes[pos] & 0xFF;
  fields.push({ key: prefix + "sysType", label: "系统类型", value: sysType + " (" + (SYSTEM_TYPES[sysType] || "未知") + ")", group: group, uiType: "badge", color: "blue" });
  pos++;
  fields.push({ key: prefix + "sysAddr", label: "系统地址", value: "" + (bytes[pos] & 0xFF), group: group });
  pos++;
  var partType = bytes[pos] & 0xFF;
  fields.push({ key: prefix + "partType", label: "部件类型", value: partType + " (" + (COMPONENT_TYPES[partType] || "未知") + ")", group: group, uiType: "badge", color: "purple" });
  pos++;
  var partAddr = (bytes[pos] & 0xFF) + "." + (bytes[pos+1] & 0xFF) + "." + (bytes[pos+2] & 0xFF) + "." + (bytes[pos+3] & 0xFF);
  fields.push({ key: prefix + "partAddr", label: "部件地址", value: partAddr, group: group });
  pos += 4;
  var explainBytes = bytes.slice(pos, pos + 31);
  var explain = "";
  for (var i = 0; i < 31; i++) {
    if (explainBytes[i] === 0) break;
    explain += String.fromCharCode(explainBytes[i]);
  }
  fields.push({ key: prefix + "partExplain", label: "部件说明", value: explain || "(空)", group: group });
}

// Type8: 系统时间 [系统类型1B][系统地址1B][时间6B] = 8B
function parseType8(bytes, pos, end, fields, group, prefix) {
  if (pos + 8 > end) return;
  var sysType = bytes[pos] & 0xFF;
  fields.push({ key: prefix + "sysType", label: "系统类型", value: sysType + " (" + (SYSTEM_TYPES[sysType] || "未知") + ")", group: group, uiType: "badge", color: "blue" });
  pos++;
  fields.push({ key: prefix + "sysAddr", label: "系统地址", value: "" + (bytes[pos] & 0xFF), group: group });
  pos++;
  fields.push({ key: prefix + "time", label: "系统时间", value: readTime(bytes, pos), group: group });
}

// Type21: 传输装置运行状态 [运行状态1B][时间6B] = 7B
function parseType21(bytes, pos, end, fields, group, prefix) {
  if (pos + 7 > end) return;
  var statusByte = [bytes[pos]];
  var statusStr = bitMapToString(statusByte, TRANS_STATUS_BITS);
  fields.push({ key: prefix + "runStatus", label: "运行状态", value: statusStr, group: group });
  var alarmItems = parseBitMap(statusByte, TRANS_STATUS_BITS);
  for (var b = 0; b < alarmItems.length; b++) {
    var item = alarmItems[b];
    var c = item.set === 1 ? (item.bit >= 1 ? "red" : "emerald") : "emerald";
    if (item.bit === 0 && item.set === 1) c = "emerald";
    fields.push({ key: prefix + "transBit" + item.bit, label: "Bit" + item.bit, value: item.desc, group: group, uiType: "status-dot", color: c });
  }
  pos++;
  fields.push({ key: prefix + "time", label: "发生时间", value: readTime(bytes, pos), group: group });
}

// Type24: 传输装置操作信息 [操作类型1B][操作员号1B][时间6B] = 8B
function parseType24(bytes, pos, end, fields, group, prefix) {
  if (pos + 8 > end) return;
  var opByte = [bytes[pos]];
  var opItems = parseBitMap(opByte, TRANS_OPERATE_BITS);
  var opStrs = [];
  for (var i = 0; i < opItems.length; i++) {
    if (opItems[i].set === 1 && opItems[i].desc.length > 0) opStrs.push(opItems[i].desc);
  }
  fields.push({ key: prefix + "operateType", label: "操作类型", value: opStrs.length > 0 ? opStrs.join(", ") : "无操作", group: group, uiType: "badge", color: "amber" });
  pos++;
  fields.push({ key: prefix + "operatorNum", label: "操作员号", value: "" + (bytes[pos] & 0xFF), group: group });
  pos++;
  fields.push({ key: prefix + "time", label: "发生时间", value: readTime(bytes, pos), group: group });
}

// Type25: 传输装置软件版本 [主版本1B][次版本1B] = 2B
function parseType25(bytes, pos, end, fields, group, prefix) {
  if (pos + 2 > end) return;
  fields.push({ key: prefix + "version", label: "软件版本", value: (bytes[pos] & 0xFF) + "." + (bytes[pos+1] & 0xFF), group: group });
}

// Type26: 传输装置配置 [配置长度1B][配置描述NB]
function parseType26(bytes, pos, end, fields, group, prefix) {
  if (pos + 1 > end) return;
  var confLen = bytes[pos] & 0xFF;
  pos++;
  var confData = bytes.slice(pos, Math.min(pos + confLen, end));
  var confStr = "";
  for (var i = 0; i < confData.length; i++) {
    if (confData[i] === 0) break;
    confStr += String.fromCharCode(confData[i]);
  }
  fields.push({ key: prefix + "transConf", label: "装置配置", value: confStr || bytesToHex(confData), group: group });
}

// Type28: 传输装置系统时间 [时间6B] = 6B
function parseType28(bytes, pos, end, fields, group, prefix) {
  if (pos + 6 > end) return;
  fields.push({ key: prefix + "time", label: "系统时间", value: readTime(bytes, pos), group: group });
}

// ═══════════════════════════════════════════
//  解析器入口
// ═══════════════════════════════════════════

function parse(rawData) {
  try {
    var hex = rawData.replace(/\s+/g, "").toUpperCase();

    // 基本校验
    if (hex.length < 4 || hex.substring(0, 4) !== "4040") {
      return { success: false, protocolName: "GB26875", summary: "",
               fields: [], error: "非 GB26875 报文：缺少起始符 @@ (4040)" };
    }
    if (hex.length < 58) {
      return { success: false, protocolName: "GB26875", summary: "",
               fields: [], error: "报文长度不足：最少需要29字节" };
    }

    var bytes = hexToBytes(hex);
    var fields = [];
    var pos = 0;

    // 起始符 @@ (2B)
    fields.push({ key: "header", label: "起始符", value: "@@ (4040)", group: "帧头", uiType: "code" });
    pos = 2;

    // 业务流水号 (2B 小端)
    var serialNum = readUint16LE(bytes, pos);
    fields.push({ key: "serialNum", label: "业务流水号", value: "" + serialNum + " (H" + padHex(serialNum, 4) + ")", group: "帧头" });
    pos += 2;

    // 协议版本 (2B: 主版本+用户版本)
    var mainVer = bytes[pos] & 0xFF;
    var userVer = bytes[pos + 1] & 0xFF;
    fields.push({ key: "version", label: "协议版本", value: mainVer + "." + userVer, group: "帧头" });
    pos += 2;

    // 时间标签 (6B)
    var timestamp = readTime(bytes, pos);
    fields.push({ key: "timestamp", label: "时间标签", value: timestamp, group: "帧头" });
    pos += 6;

    // 源地址 (6B)
    var srcAddr = formatMac(bytes, pos);
    fields.push({ key: "srcAddr", label: "源地址", value: srcAddr, group: "帧头", isKeyInfo: true });
    pos += 6;

    // 目的地址 (6B)
    var dstAddr = formatMac(bytes, pos);
    fields.push({ key: "dstAddr", label: "目的地址", value: dstAddr, group: "帧头" });
    pos += 6;

    // 应用数据长度 (2B 小端)
    var appDataLen = readUint16LE(bytes, pos);
    fields.push({ key: "appDataLen", label: "应用数据长度", value: appDataLen + " 字节", group: "帧头" });
    pos += 2;

    // 命令字节 (1B)
    var controlOrder = bytes[pos] & 0xFF;
    var orderName = getControlOrder(controlOrder);
    var orderColor = controlOrder === 2 ? "emerald" : controlOrder === 1 ? "red" : controlOrder === 4 ? "blue" : controlOrder === 5 ? "blue" : "slate";
    fields.push({
      key: "controlOrder", label: "命令字节",
      value: controlOrder + " (" + orderName + ")",
      group: "帧头", uiType: "badge", color: orderColor, isKeyInfo: true
    });
    pos += 1;

    // 应用数据 (NB)
    if (appDataLen > 0 && pos + appDataLen <= bytes.length - 3) {
      parseAppData(bytes, pos, appDataLen, fields);
      pos += appDataLen;
    } else if (appDataLen > 0) {
      var actualLen = bytes.length - 3 - pos;
      if (actualLen > 0) {
        parseAppData(bytes, pos, actualLen, fields);
        fields.push({
          key: "_lenWarning", label: "长度警告",
          value: "声明长度 " + appDataLen + " 字节，实际可用 " + actualLen + " 字节",
          group: "诊断", uiType: "status-dot", color: "amber"
        });
        pos += actualLen;
      }
    }

    // 校验和 (1B)
    if (pos < bytes.length) {
      var recvCheck = bytes[pos] & 0xFF;
      var calcCheck = computeChecksum(bytes, 2, pos);
      var checkOk = recvCheck === calcCheck;
      var checkDisplay = padHex(recvCheck, 2);
      if (checkOk) {
        checkDisplay += " \u2713 校验通过";
      } else {
        checkDisplay += " \u2717 校验失败 (预期 " + padHex(calcCheck, 2) + ")";
      }
      fields.push({
        key: "checksum", label: "校验和",
        value: checkDisplay,
        group: "帧尾", uiType: "status-dot", color: checkOk ? "emerald" : "red", isKeyInfo: true
      });
      pos++;
    }

    // 结束符 ## (2B)
    if (pos + 2 <= bytes.length) {
      var footer = bytesToHex(bytes.slice(pos, pos + 2));
      var footerOk = footer === "2323";
      fields.push({
        key: "footer", label: "结束符",
        value: footerOk ? "## (2323)" : footer + " (异常，预期 2323)",
        group: "帧尾", uiType: "code", color: footerOk ? undefined : "red"
      });
    }

    // 总长度
    fields.push({ key: "totalLen", label: "报文总长度", value: bytes.length + " 字节", group: "帧尾" });

    // 摘要
    var typeName = "";
    for (var fi = 0; fi < fields.length; fi++) {
      if (fields[fi].key === "dataType") { typeName = fields[fi].value; break; }
    }
    var summary = "GB26875 " + orderName + " [" + srcAddr + "]";
    if (typeName) summary += " " + typeName;

    var layout = buildLayout(fields);

    return {
      success: true,
      protocolName: "GB26875",
      summary: summary,
      fields: fields,
      layout: layout
    };

  } catch (e) {
    return {
      success: false,
      protocolName: "GB26875",
      summary: "",
      fields: [],
      error: "解析异常: " + e.toString()
    };
  }
}

// ═══════════════════════════════════════════
//  Layout 布局生成
// ═══════════════════════════════════════════

function buildLayout(fields) {
  var sections = [];
  var groupMap = {};
  var groupOrder = [];
  for (var i = 0; i < fields.length; i++) {
    var f = fields[i];
    var g = f.group || "__ungrouped";
    if (!groupMap[g]) { groupMap[g] = []; groupOrder.push(g); }
    groupMap[g].push(f);
  }

  var styleMap = {
    "帧头": { style: "key-value", color: "blue" },
    "应用数据": { style: "key-value", color: "teal" },
    "帧尾": { style: "key-value", color: "slate" },
    "诊断": { style: "key-value", color: "amber" }
  };

  for (var gi = 0; gi < groupOrder.length; gi++) {
    var group = groupOrder[gi];
    var gFields = groupMap[group];
    var mapping = styleMap[group] || { style: "key-value", color: "indigo" };
    var keys = [];
    for (var ki = 0; ki < gFields.length; ki++) keys.push(gFields[ki].key);
    sections.push({ title: group, style: mapping.style, color: mapping.color, fieldKeys: keys });
  }

  return { sections: sections };
}

// ═══════════════════════════════════════════
//  报文生成器
// ═══════════════════════════════════════════

function generate(params) {
  try {
    var serialNum = parseInt(params.serialNum || "1");
    var mainVersion = parseInt(params.mainVersion || "1");
    var userVersion = parseInt(params.userVersion || "0");
    var controlOrder = parseInt(params.controlOrder || "2");
    var srcMac = params.srcAddress || "00:00:00:00:00:01";
    var dstMac = params.dstAddress || "00:00:00:00:00:02";
    var appDataHex = (params.appData || "").replace(/\s+/g, "");

    var appDataBytes = appDataHex.length > 0 ? hexToBytes(appDataHex) : [];

    var packet = [];
    // 起始符
    packet.push(0x40, 0x40);
    // 流水号(小端)
    var snLE = writeUint16LE(serialNum);
    packet.push(snLE[0], snLE[1]);
    // 版本
    packet.push(mainVersion & 0xFF, userVersion & 0xFF);
    // 时间戳(当前时间, 秒/分/时/日/月/年-2000)
    var now = new Date();
    packet.push(now.getSeconds(), now.getMinutes(), now.getHours(),
                now.getDate(), now.getMonth() + 1, now.getFullYear() - 2000);
    // 源地址
    var srcParts = srcMac.split(":");
    for (var i = 0; i < 6; i++) packet.push(parseInt(srcParts[i] || "0", 16));
    // 目的地址
    var dstParts = dstMac.split(":");
    for (var j = 0; j < 6; j++) packet.push(parseInt(dstParts[j] || "0", 16));
    // 数据长度(小端)
    var lenLE = writeUint16LE(appDataBytes.length);
    packet.push(lenLE[0], lenLE[1]);
    // 命令字节
    packet.push(controlOrder & 0xFF);
    // 应用数据
    for (var k = 0; k < appDataBytes.length; k++) packet.push(appDataBytes[k]);
    // 校验和
    var checksum = computeChecksum(packet, 2, packet.length);
    packet.push(checksum);
    // 结束符
    packet.push(0x23, 0x23);

    var message = bytesToHex(packet);

    return {
      success: true,
      protocolName: "GB26875",
      message: message,
      formatted: message.replace(/(.{2})/g, "$1 ").trim()
    };

  } catch (e) {
    return {
      success: false,
      protocolName: "GB26875",
      message: "",
      error: "生成异常: " + e.toString()
    };
  }
}
