/**
 * curl-exporter — cURL 命令导出插件
 *
 * 接收标准化的请求 JSON 对象，输出可直接在终端执行的 cURL 命令。
 *
 * exportRequest(request) → { content: "curl ...", filename: "request.sh", mimeType: "text/x-shellscript" }
 *
 * request 格式:
 * {
 *   method: "GET",
 *   url: "https://example.com/api",
 *   headers: { "Content-Type": "application/json", ... },
 *   queryParams: { "page": "1", ... },
 *   body: { type: "json"|"raw"|"none", data: "..." },
 *   auth: { type: "bearer"|"basic"|"none", token: "...", username: "...", password: "..." }
 * }
 */

function exportRequest(request) {
  var parts = ["curl"];

  // Method
  var method = (request.method || "GET").toUpperCase();
  if (method !== "GET") {
    parts.push("-X " + method);
  }

  // URL with query params
  var url = request.url || "";
  if (request.queryParams) {
    var qp = [];
    var keys = Object.keys(request.queryParams);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      var v = request.queryParams[k];
      qp.push(encodeURIComponent(k) + "=" + encodeURIComponent(v));
    }
    if (qp.length > 0) {
      var separator = url.indexOf("?") >= 0 ? "&" : "?";
      url = url + separator + qp.join("&");
    }
  }
  parts.push(shellQuote(url));

  // Headers
  if (request.headers) {
    var hkeys = Object.keys(request.headers);
    for (var h = 0; h < hkeys.length; h++) {
      var hk = hkeys[h];
      var hv = request.headers[hk];
      parts.push("-H " + shellQuote(hk + ": " + hv));
    }
  }

  // Auth
  if (request.auth) {
    if (request.auth.type === "bearer" && request.auth.token) {
      parts.push("-H " + shellQuote("Authorization: Bearer " + request.auth.token));
    } else if (request.auth.type === "basic" && request.auth.username) {
      parts.push("-u " + shellQuote(request.auth.username + ":" + (request.auth.password || "")));
    }
  }

  // Body
  if (request.body) {
    if (request.body.type === "json" && request.body.data) {
      parts.push("-d " + shellQuote(request.body.data));
    } else if (request.body.type === "raw" && request.body.content) {
      parts.push("-d " + shellQuote(request.body.content));
    }
  }

  var content = parts.join(" \\\n  ");

  return {
    content: content,
    filename: "request.sh",
    mimeType: "text/x-shellscript"
  };
}

// Shell-safe quoting
function shellQuote(str) {
  // Use single quotes, escape any embedded single quotes
  return "'" + str.replace(/'/g, "'\\''") + "'";
}
