/**
 * JSON Array → CSV Export Plugin
 *
 * 从 JSON 响应体中按指定路径提取数组，导出为 CSV。
 * 在 Boa JS 引擎中运行，无外部依赖。
 *
 * exportResponse(data) 接口：
 *   data.body       — JSON 响应体字符串
 *   data.params.jsonPath — 数组节点路径（如 "data.list"、"(root)"）
 *
 * 返回 ExportResult:
 *   { content, filename, mimeType, error? }
 */

function exportResponse(data) {
  try {
    var body = JSON.parse(data.body);
    var jsonPath = data.params && data.params.jsonPath ? data.params.jsonPath : '(root)';

    // 按路径取值
    var arr = getByPath(body, jsonPath);
    if (!arr || !isArray(arr)) {
      return {
        content: '',
        filename: 'export.csv',
        mimeType: 'text/csv',
        error: '指定路径 "' + jsonPath + '" 不是数组或不存在'
      };
    }

    if (arr.length === 0) {
      return {
        content: '',
        filename: 'export.csv',
        mimeType: 'text/csv',
        error: '数组为空，无数据可导出'
      };
    }

    // 收集所有列名（遍历每个对象取 key 并集）
    var columns = collectColumns(arr);

    // 生成 CSV 内容
    var lines = [];

    // UTF-8 BOM + 表头
    var bom = '\uFEFF';
    lines.push(columns.map(escapeCsvField).join(','));

    // 数据行
    for (var i = 0; i < arr.length; i++) {
      var row = arr[i];
      var cells = [];
      for (var j = 0; j < columns.length; j++) {
        var val = getCellValue(row, columns[j]);
        cells.push(escapeCsvField(val));
      }
      lines.push(cells.join(','));
    }

    var csv = bom + lines.join('\r\n');

    // 生成文件名
    var pathSuffix = jsonPath === '(root)' ? 'root' : jsonPath.replace(/[\.\[\]]/g, '_');
    var filename = 'export_' + pathSuffix + '.csv';

    return {
      content: csv,
      filename: filename,
      mimeType: 'text/csv'
    };
  } catch (e) {
    return {
      content: '',
      filename: 'export.csv',
      mimeType: 'text/csv',
      error: '导出失败: ' + String(e)
    };
  }
}

// ── 工具函数 ──

function isArray(obj) {
  return Object.prototype.toString.call(obj) === '[object Array]';
}

/**
 * 按点分路径取值，支持数组索引 [0]
 */
function getByPath(obj, path) {
  if (path === '(root)') return obj;
  // 将 [0] 转为 .0
  var parts = path.replace(/\[(\d+)\]/g, '.$1').split('.');
  var current = obj;
  for (var i = 0; i < parts.length; i++) {
    if (current == null || typeof current !== 'object') return undefined;
    current = current[parts[i]];
  }
  return current;
}

/**
 * 收集数组中所有对象的 key 并集（保持出现顺序）
 */
function collectColumns(arr) {
  var seen = {};
  var columns = [];
  for (var i = 0; i < arr.length; i++) {
    var item = arr[i];
    if (item && typeof item === 'object' && !isArray(item)) {
      var keys = Object.keys(item);
      for (var j = 0; j < keys.length; j++) {
        if (!seen[keys[j]]) {
          seen[keys[j]] = true;
          columns.push(keys[j]);
        }
      }
    }
  }
  // 如果数组元素不是对象（如纯字符串/数字数组），用 "value" 作为列名
  if (columns.length === 0) {
    columns.push('value');
  }
  return columns;
}

/**
 * 获取单元格值，嵌套对象/数组转为 JSON 字符串
 */
function getCellValue(row, column) {
  if (row == null) return '';
  if (typeof row !== 'object' || isArray(row)) {
    // 非对象行（纯值数组），column 必为 'value'
    return formatValue(row);
  }
  var val = row[column];
  return formatValue(val);
}

function formatValue(val) {
  if (val === null || val === undefined) return '';
  if (typeof val === 'object') {
    try {
      return JSON.stringify(val);
    } catch (e) {
      return String(val);
    }
  }
  return String(val);
}

/**
 * CSV 字段转义：包含逗号、引号、换行符时用双引号包裹
 */
function escapeCsvField(val) {
  var str = String(val);
  if (str.indexOf(',') >= 0 || str.indexOf('"') >= 0 || str.indexOf('\n') >= 0 || str.indexOf('\r') >= 0) {
    return '"' + str.replace(/"/g, '""') + '"';
  }
  return str;
}
